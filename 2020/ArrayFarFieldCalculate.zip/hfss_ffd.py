# -*- coding: utf-8 -*-
"""
Created on Sun Dec  8 15:26:28 2019

@author: mlin
"""
import os, re
import numpy as np
import itertools
from numpy import sin, cos, exp, pi, radians, degrees, sqrt
import copy
import matplotlib.pyplot as plt
import scipy.ndimage.filters as filters

theta_range = map(radians, range(181))
phi_range = map(radians, range(361))
Vp=[]        
for i, j in itertools.product(theta_range, phi_range):
    Vp.append((sin(i)*cos(j), sin(i)*sin(j), cos(i)))

def point_plane(theta, phi, point, wavelength):
    theta=radians(theta)
    phi=radians(phi)
    A=sin(theta)*cos(phi)
    B=sin(theta)*sin(phi)
    C=cos(theta)
    x1, y1, z1 = point
    distance=A*x1+B*y1+C*z1/(A*A+B*B+C*C)
    result=-degrees(2*pi*distance/wavelength)
    return result

class ffd():
    def __init__(self, ffdpath, vector=(0,0,0)):
        self.portname=os.path.basename(ffdpath).split('.')[0]
        self.ffd = ffdpath
        self.power=1
        self.phase=0
        self.vector=vector       
        self.readheader()

        EF=np.loadtxt(ffdpath, skiprows=4)
        Etheta=np.vectorize(complex)(EF[:,0], EF[:,1])
        Ephi=np.vectorize(complex)(EF[:,2], EF[:,3])
        self.field=np.column_stack((Etheta, Ephi))
    
    def readheader(self):
        with open(self.ffd) as f:
            theta=f.readline()
            phi=f.readline()
            fnum=f.readline()
            self.freq=float(f.readline().split()[1])
            self.wavelength=299792458/self.freq
            
    def setPower(self, power=1):
        if power==0:
            power=1e-18
        factor=sqrt(power/self.power)
        self.power=power
        self.field=self.field*factor
        return self
    
    def setPhase(self, phase=0):
        factor=phase-self.phase
        self.phase=phase
        self.field=self.field*np.exp(1j*np.radians(factor))
        return self
                
    def offset(self, vector):      
        m=[2*pi*i/self.wavelength for i in vector]
        angle=[i[0]*m[0]+i[1]*m[1]+i[2]*m[2] for i in Vp]
        dp=np.array([[exp(1j*i), exp(1j*i)] for i in angle])
        
        result=copy.deepcopy(self)
        result.vector=vector
        result.field=self.field*dp
        
        return result

    def __add__(self, other):
        if self.freq != other.freq:
            raise Exception('Frequency mismatch!')
            
        result=copy.deepcopy(self)
        result.field=self.field+other.field
        result.power=self.power+other.power
        result.ffd=''
        self.vector=None
        return result
    
    def getinfo(self):
        location=[i+'meter' for i in map(str, self.vector)]
        return ' '.join(location)+f' {sqrt(self.power)}V {self.phase}deg'
    
    
    def getRealizedGain(self):
        pd=np.sum(np.power(np.absolute(self.field), 2),1)/377/2
        x=[]
        for i in range(181):
            x+=[i]*361
        #self.cell_area=radians(1)*radians(1)*sin(radians(np.array(x)))
        self.realized_gain=10*np.log10(pd/(self.power/4/np.pi))
        size=(181, 361)
        self.gain_map=self.realized_gain.reshape(size)
        return self.realized_gain
    
    def plotRealizedGain(self, contour=True):
        self.getRealizedGain()
        gain_map=self.gain_map
        
        plt.figure(figsize=(10, 5))
        plt.title('Map of Realized Gain(dB)')
        plt.xlabel('Phi (degree)')
        plt.ylabel('Theta (degree)')
        maxV=np.max(gain_map)
        [row, col] = np.where(gain_map==maxV)
        plt.plot(col, row, 'w*')
        plt.annotate(round(maxV,3), (col+3, row+3), color='white')
        plt.imshow(gain_map, vmin=-50, cmap='jet')
        plt.colorbar()     
        if contour:
            CS=plt.contour(gain_map)        
            #plt.clabel(CS, inline=1, fontsize=10)
        plt.show()
        plt.close()
        print(f'Peak Realized Gain: {round(maxV, 3)} dB')
        return maxV
    
    def getlobes(self, scope=90):
        self.getRealizedGain()
        self.mf=filters.maximum_filter(self.gain_map, 5)
        localmax=[]
        for i in range(int(90-scope/2), int(90+scope/2)):
            for j in range(int(180-scope/2), int(180+scope/2)):
                if self.gain_map[i,j]>=self.mf[i,j]:
                    localmax.append((self.gain_map[i,j],i,j))
        
        localmax.sort()
        return(localmax)

def sumffd(*argc):
    result=copy.deepcopy(argc[0])
    for i in argc[1:]:
        result+=i
    return result


class rect_array():   
    def __init__(self, ffdpath):
        self.ffd=ffd(ffdpath)
        self.freq=self.ffd.freq
        self.wavelegnth=self.ffd.wavelength
        self.incidentpower=0
    
    def setSize(self, Nu=8, Nv=8, lambdaU=0.5, lambdaV=0.5):
        Su=lambdaU*self.ffd.wavelength
        Sv=lambdaV*self.ffd.wavelength
        
        P0u=-(Nu-1)*Su/2
        P0v=-(Nv-1)*Sv/2
        self.Nu=Nu
        self.Nv=Nv
        self.grid=[]
        for i in range(Nu):
            for j in range(Nv):
                x=self.ffd.offset((0, Su*i+P0u, Sv*j+P0v))
                self.grid+=[x]
                self.incidentpower+=x.power
                
        print('Grid Built!')
        
    def setWeighting(self, weighting_fun):
        self.incidentpower=0
        for i in self.grid:
            p=weighting_fun(i.vector)
            i.setPower(p)
            self.incidentpower+=p
    
    def setDeltaPhase(self, dPu=0, dPv=0):
        for i in range(self.Nu):
            for j in range(self.Nv):        
                self.grid[i*self.Nv+j].setPhase(i*dPu+j*dPv)        

    def steer(self, theta, phi):
        for i in self.grid:
            dphase=point_plane(theta, phi, i.vector, i.wavelength)
            i.setPhase(dphase)    

    def plotRealizedGain(self, contour=True):
        self.beam=sumffd(*self.grid)
        peak_Realized_gain=self.beam.plotRealizedGain(contour)
        return peak_Realized_gain
    
    def export(self, file='custom_array.txt'):
        data=[i.getinfo() for i in self.grid]
        with open(file, 'w') as f:
            f.writelines(f'{len(data)}\n')
            f.writelines('\n'.join(data))
    
    def getSideLobeLevel(self):
        self.beam=sumffd(*self.grid)
        x=self.beam.getlobes()
        main_lobe=x[-1][0]
        second_lobe=x[-2][0]
        return main_lobe-second_lobe
    
    def plotgrid(self):
        plt.clf()
        plt.figure(figsize=(8, 8))
        plt.title(f'Total Incident Power: {self.incidentpower}')
        x, y, p= zip(*[(i.vector[1], i.vector[2], i.power) for i in self.grid])
        plt.scatter(x, y, s=[i*100 for i in p], c=p, alpha=0.5)
        
        power_txt=[f'{round(i.power,2)}' for i in self.grid]
        phase_txt=[f'{round(i.phase,1)}' for i in self.grid]
        
        for i, txt in enumerate(power_txt):
            plt.annotate(txt, (x[i]-0.002, y[i]-0.002))
            
        for i, txt in enumerate(phase_txt):
            plt.annotate(txt, (x[i]-0.002, y[i]-0.004))
        plt.show() 


def readcsv(csvpath):
    with open(csvpath) as f:
        text=f.readlines()
    result={}
    for i in text[1:]:
        m=re.search('(.+):.*,(.*)W,(.*)deg', i.strip())
        name=m.group(1)
        mag=float(m.group(2))
        phase=float(m.group(3))
        result[name]=(mag, phase)
    return result

def writecsv(excitation, csvpath):
    text='Source,Magnitude,Phase\n'
    for i in excitation:
        mag, phase=excitation[i]
        text+='{}:1,{}W,{}deg\n'.format(i, mag, phase)
    with open(csvpath, 'w') as f:
        f.writelines(text)
            
class custom_array():
    def __init__(self, grid):
        self.grid=grid
        yrange, zrange=[], []
        
        for i in self.grid:
            yrange+=[i.vector[1]]
            zrange+=[i.vector[2]]
        dy=(max(yrange)+min(yrange))/2
        dz=(max(zrange)+min(zrange))/2
        for i in self.grid:
            i.vector=(0, i.vector[1]-dy, i.vector[2]-dz)
            
        self.beam=sumffd(*self.grid)
        self.incidentpower=self.beam.power
        
    def setWeighting(self, weighting_fun):
        self.incidentpower=0
        for i in self.grid:
            p=weighting_fun(i.vector)
            i.setPower(p)
            self.incidentpower+=p

    def __add__(self, other):
        result=self.grid+other.grid
        return custom_array(result)        
    
    
    def setExcitation(self, mag=1, phase=0):
        self.incidentpower=0
        for i in self.grid:
            i.setPower(mag)
            i.setPhase(phase)
            self.incidentpower+=mag
            
            
    def readExcitationCSV(self, csvpath):
        excitations=readcsv(csvpath)
        for i in self.grid:
            i.setPower(excitations[i.portname][0])
            i.setPhase(excitations[i.portname][1])
            
    def writeExcitationCSV(self, csvpath):
        result={}
        for i in self.grid:
            result[i.portname]=(i.power, i.phase)
        writecsv(result, csvpath)
        
    def plotRealizedGain(self, contour=True):
        self.beam=sumffd(*self.grid)
        self.incidentpower=self.beam.power
        peak_Realized_gain=self.beam.plotRealizedGain(contour)
        return peak_Realized_gain
         
    def getSideLobeLevel(self):
        self.beam=sumffd(*self.grid)
        x=self.beam.getlobes()
        main_lobe=x[-1][0]
        second_lobe=x[-2][0]
        return main_lobe-second_lobe

    def steer(self, theta, phi):
        for i in self.grid:
            dphase=point_plane(theta, phi, i.vector, i.wavelength)
            i.setPhase(dphase)
   
    def plotgrid(self):
        plt.clf()
        plt.figure(figsize=(8, 8))
        plt.title(f'Total Incident Power: {self.incidentpower}')
        x, y, p= zip(*[(i.vector[1], i.vector[2], i.power) for i in self.grid])
        plt.scatter(x, y, s=[i*100 for i in p], c=p, alpha=0.5)
        
        power_txt=[f'{round(i.power,2)}' for i in self.grid]
        phase_txt=[f'{round(i.phase,1)}' for i in self.grid]
        
        for i, txt in enumerate(power_txt):
            plt.annotate(txt, (x[i]-0.002, y[i]-0.002))
            
        for i, txt in enumerate(phase_txt):
            plt.annotate(txt, (x[i]-0.002, y[i]-0.004))
        plt.show()
        plt.close()        

