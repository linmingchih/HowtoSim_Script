# -*- coding: utf-8 -*-
"""
Created on Tue Nov 26 08:35:04 2019
Let antenna pattatern face -X axis to locate beam in center of gain map.
@author: mlin
"""
from hfss_ffd import ffd, rect_array, custom_array
import matplotlib.pyplot as plt
from math import sqrt
    
path='./27000000000'
dy=dz=0.0055517
gridH, gridV=[], []
gridH.append(ffd(path+'/element1_Bump_H1.ffd', (0, dy*0, dz*0)))
gridH.append(ffd(path+'/element2_Bump_H1.ffd', (0, dy*1, dz*0)))
gridH.append(ffd(path+'/element3_Bump_H1.ffd', (0, dy*2, dz*0)))
gridH.append(ffd(path+'/element4_Bump_H1.ffd', (0, dy*3, dz*0)))
gridH.append(ffd(path+'/element5_Bump_H1.ffd', (0, dy*0, dz*1)))
gridH.append(ffd(path+'/element6_Bump_H1.ffd', (0, dy*0, dz*2)))
gridH.append(ffd(path+'/element7_Bump_H1.ffd', (0, dy*0, dz*3)))
gridH.append(ffd(path+'/element8_Bump_H1.ffd', (0, dy*1, dz*1)))
gridH.append(ffd(path+'/element9_Bump_H1.ffd', (0, dy*1, dz*2)))
gridH.append(ffd(path+'/element10_Bump_H1.ffd', (0, dy*1, dz*3)))
gridH.append(ffd(path+'/element11_Bump_H1.ffd', (0, dy*2, dz*1)))
gridH.append(ffd(path+'/element12_Bump_H1.ffd', (0, dy*2, dz*2)))
gridH.append(ffd(path+'/element13_Bump_H1.ffd', (0, dy*2, dz*3)))
gridH.append(ffd(path+'/element14_Bump_H1.ffd', (0, dy*3, dz*1)))
gridH.append(ffd(path+'/element15_Bump_H1.ffd', (0, dy*3, dz*2)))
gridH.append(ffd(path+'/element16_Bump_H1.ffd', (0, dy*3, dz*3)))
gridH.append(ffd(path+'/element17_Bump_H1.ffd', (0, dy*1, dz*4)))
gridH.append(ffd(path+'/element18_Bump_H1.ffd', (0, dy*2, dz*4)))
gridH.append(ffd(path+'/element19_Bump_H1.ffd', (0, dy*4, dz*2)))
gridH.append(ffd(path+'/element20_Bump_H1.ffd', (0, dy*4, dz*1)))
gridH.append(ffd(path+'/element21_Bump_H1.ffd', (0, dy*1, dz*-1)))
gridH.append(ffd(path+'/element22_Bump_H1.ffd', (0, dy*2, dz*-1)))
gridH.append(ffd(path+'/element23_Bump_H1.ffd', (0, dy*-1, dz*2)))
gridH.append(ffd(path+'/element24_Bump_H1.ffd', (0, dy*-1, dz*1)))

gridV.append(ffd(path+'/element1_Bump_V1.ffd', (0, dy*0, dz*0)))
gridV.append(ffd(path+'/element2_Bump_V1.ffd', (0, dy*1, dz*0)))
gridV.append(ffd(path+'/element3_Bump_V1.ffd', (0, dy*2, dz*0)))
gridV.append(ffd(path+'/element4_Bump_V1.ffd', (0, dy*3, dz*0)))
gridV.append(ffd(path+'/element5_Bump_V1.ffd', (0, dy*0, dz*1)))
gridV.append(ffd(path+'/element6_Bump_V1.ffd', (0, dy*0, dz*2)))
gridV.append(ffd(path+'/element7_Bump_V1.ffd', (0, dy*0, dz*3)))
gridV.append(ffd(path+'/element8_Bump_V1.ffd', (0, dy*1, dz*1)))
gridV.append(ffd(path+'/element9_Bump_V1.ffd', (0, dy*1, dz*2)))
gridV.append(ffd(path+'/element10_Bump_V1.ffd', (0, dy*1, dz*3)))
gridV.append(ffd(path+'/element11_Bump_V1.ffd', (0, dy*2, dz*1)))
gridV.append(ffd(path+'/element12_Bump_V1.ffd', (0, dy*2, dz*2)))
gridV.append(ffd(path+'/element13_Bump_V1.ffd', (0, dy*2, dz*3)))
gridV.append(ffd(path+'/element14_Bump_V1.ffd', (0, dy*3, dz*1)))
gridV.append(ffd(path+'/element15_Bump_V1.ffd', (0, dy*3, dz*2)))
gridV.append(ffd(path+'/element16_Bump_V1.ffd', (0, dy*3, dz*3)))
gridV.append(ffd(path+'/element17_Bump_V1.ffd', (0, dy*1, dz*4)))
gridV.append(ffd(path+'/element18_Bump_V1.ffd', (0, dy*2, dz*4)))
gridV.append(ffd(path+'/element19_Bump_V1.ffd', (0, dy*4, dz*2)))
gridV.append(ffd(path+'/element20_Bump_V1.ffd', (0, dy*4, dz*1)))
gridV.append(ffd(path+'/element21_Bump_V1.ffd', (0, dy*1, dz*-1)))
gridV.append(ffd(path+'/element22_Bump_V1.ffd', (0, dy*2, dz*-1)))
gridV.append(ffd(path+'/element23_Bump_V1.ffd', (0, dy*-1, dz*2)))
gridV.append(ffd(path+'/element24_Bump_V1.ffd', (0, dy*-1, dz*1)))

#%%
h=custom_array(gridH)
h.steer(90,180)
h.plotRealizedGain()
v=custom_array(gridV)
v.setExcitation(0,0)
(h+v).writeExcitationCSV('./90_180.csv')


#%%
h.steer(120,210)
h.plotRealizedGain()
(h+v).writeExcitationCSV('./120_210.csv')


#%%
h.steer(120,210)
v.setExcitation(1,0)
v.steer(75,150)
(h+v).writeExcitationCSV('./twoBeam.csv')
(h+v).plotRealizedGain()

#%%
(h+v).readExcitationCSV('./90_180.csv')
(h+v).plotRealizedGain()
h.plotgrid()
v.plotgrid()
