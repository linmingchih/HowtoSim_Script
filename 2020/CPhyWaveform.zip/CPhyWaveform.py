# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 13:33:10 2020

@author: mlin
"""
symbol_count=10000
symbol_rate=2.5e9
samples_per_symbol=10
volage=0.2

###############################################################################
oProject = oDesktop.GetActiveProject()
path=oProject.GetPath()


import random
Level={'+X':(1, -1, 0), 
       '+Y':(0, -1, 1), 
       '+Z':(-1, 0, 1), 
       '-X':(-1, 1, 0), 
       '-Y':(0, 1, -1), 
       '-Z':(1, 0, -1)}

status=[i for i in Level]

Transition={}
for i in status:
    x=status[:]
    x.remove(i)
    Transition[i]=x

bits=[random.randint(0, 4) for i in range(symbol_count)]
S0='+X'
status_list=[]
for i in bits:
    S0=Transition[S0][i]
    status_list.append(S0)

waveform=[]
level_list=[Level[i] for i in status_list]
for i in level_list:
    for j in range(samples_per_symbol):
        waveform.append(i)
    
data={}
data['Va'], data['Vb'], data['Vc'] = zip(*waveform)
time=[i*1.0/(samples_per_symbol*symbol_rate) for i in range(len(waveform))]

for name in data:
    with open('{}/{}.txt'.format(path, name), 'w') as f:
        for t, i in zip(time, data[name]):
            f.writelines('{:.6e} {:2}\n'.format(t, i*volage))