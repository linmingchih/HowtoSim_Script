# -*- coding: utf-8 -*-
# ----------------------------------------------
# Script Recorded by ANSYS Electronics Desktop Version 2020.1.0
# 4:59:26  Feb 21, 2020
# ----------------------------------------------
import re, os, time
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oDesktop.ClearMessages("", "", 2)
os.chdir(oProject.GetPath())
mask_width=0.2e-9
mask_height=0.05

Tstart=time.time()
def exportWaveforms(report='CPHY'):
    oModule = oDesign.GetModule("ReportSetup")
    try:
        oModule.ExportToFile(report, "temp.csv", False)
    except:
        AddErrorMessage("Can't fine Report named of 'CPHY'!")
    with open('temp.csv') as f:
        text=f.readlines()

    m=re.search('\[(.*)\]',text[0].split(',')[0])
    unit=m.group(1)
    for i in text[1:]:
        try:
            tstamp, vab, vbc, vca=i.split(',')
            tstop=tstamp
        except:
            pass
    try:        
        Tstop=tstop+unit
    except:
        AddErrorMessage("Report Data Error!")
        
    oModule.ExportUniformPointsToFile(report, "waveforms.csv", "0ns", Tstop, "0.001ns", True)
    AddWarningMessage('"waveforms.csv" is saved!')

def computeWaveforms():
    csv_path='waveforms.csv'
    with open(csv_path) as f:
        text=f.readlines()
    
    waveforms=[]
    header=text[0]
    header.strip().split(',')
    conversion = lambda x: 1e-3 if '[mV]' in x else 1
    scale=[conversion(i) for i in header.strip().split(',')]
    
    for i in text[1:]:
        try:
            ts, vab, vbc, vca=map(float, i.strip().split(','))
            waveforms.append((ts, vab*scale[1], vbc*scale[2], vca*scale[3]))
        except:
            pass
    
    traces=[]
    interval=[]
    delta=0
    
    for n in range(len(waveforms)-1) :
        if waveforms[n][1]*waveforms[n+1][1]<0:
            interval.append(n)
    sym_len=min([i-j for i, j in zip(interval[1:], interval[:-1])])
    
    for n in range(len(waveforms)-1):
        ts0, vab0, vbc0, vca0 = waveforms[n]
        ts1, vab1, vbc1, vca1 = waveforms[n+1]
        
        if (vab0*vab1<=0 or vbc0*vbc1<=0 or vca0*vca1<=0) and n>sym_len and n<len(waveforms)-sym_len and delta>sym_len/2:
            piece=waveforms[n-int(3*sym_len/2):n+int(sym_len/2)]
            traces.append([i[1] for i in piece])
            traces.append([i[2] for i in piece])
            traces.append([i[3] for i in piece])
            delta=0
        else:
            delta+=1
    
    Tx=1e-12*int(3*sym_len/2)
    with open('mask.csv', 'w') as f:
        f.writelines('{:.18},0,0\n'.format(Tx))
        f.writelines('{:.18},{:.6},{:.6}\n'.format(Tx-mask_width/2, mask_height/2, -mask_height/2))
        f.writelines('{:.18},0,0\n'.format(Tx-mask_width))
            
    with open('eye.csv','w') as f:
        for n, i in enumerate(traces):
            ts=0
            for j in i:
                ts+=1e-12
                f.writelines('{},{:.15},{:.12}\n'.format(n,ts,j))
    return len(traces)
   
def loadTriggeredEye(traces_number):
    try:
        oDesign.RemoveImportData("mask")
    except:
        pass
    try:
        oDesign.RemoveImportData("eye")
    except:
        pass
    oDesign.ImportData(
        [
            "NAME:DataFormat",
            "DataTableFormat:="	, [			"HeaderRows:="		, 0,			"RowsToRead:="		, -1,			"ColumnSep:="		, 0,			"DataType:="		, -1,			"Sweep:="		, 2,			"Cols:="		, -1,			"Real:="		, 1]
        ], "eye.csv", True)
    oDesign.ImportData(
        [
            "NAME:DataFormat",
            "DataTableFormat:="	, [			"HeaderRows:="		, 0,			"RowsToRead:="		, -1,			"ColumnSep:="		, 0,			"DataType:="		, -1,			"Sweep:="		, 1,			"Cols:="		, -1,			"Real:="		, 1]
        ], "mask.csv", True)
    oModule = oDesign.GetModule("ReportSetup")
    
    oModule.CreateReport("Triggered Eye", "Standard", "Rectangular Plot", "eye", 
    	[
    		"NAME:Context",
    		"SimValueContext:="	, [3,0,2,0,False,False,-1,1,0,1,1,"",0,0]
    	], 
    	[
    		"sweep_col2:="		, ["All"],
    		"sweep_col1:="		, [str(i) for i in range(traces_number)]
    	], 
    	[
    		"X Component:="		, "sweep_col2",
    		"Y Component:="		, ["col1"]
    	], [])
            
    oModule.AddTraces("Triggered Eye", "mask", 
        [
            "NAME:Context",
            "SimValueContext:="	, [3,0,2,0,False,False,-1,1,0,1,1,"",0,0]
        ], 
        [
            "sweep_col1:="		, ["All"]
        ], 
        [
            "X Component:="		, "sweep_col1",
            "Y Component:="		, ["col1","col2"]
        ])
    oModule.ChangeProperty(
        [
            "NAME:AllTabs",
            [
                "NAME:Attributes",
                [
                    "NAME:PropServers", 
                    "Triggered Eye:col1_1:Curve1", 
                    "Triggered Eye:col2:Curve1"
                ],
                [
                    "NAME:ChangedProps",
                    [
                        "NAME:Color",
                        "R:="			, 0,
                        "G:="			, 0,
                        "B:="			, 255
                    ]
                ]
            ]
        ])

exportWaveforms()
col_number=computeWaveforms()
AddWarningMessage("Calculation Completed!")      
loadTriggeredEye(col_number)
AddWarningMessage("Report Created! Calculation Time:{}secs".format(time.time()-Tstart))