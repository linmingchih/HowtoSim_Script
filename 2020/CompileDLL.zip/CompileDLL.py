import os, sys

import clr
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import DialogResult, OpenFileDialog

pyc_path="C:/Program Files/AnsysEM/AnsysEM20.1/Win64/common/IronPython/Tools/Scripts/pyc.py"

dialog = OpenFileDialog()
dialog.Multiselect = True
dialog.Filter = "Python files (*.py)|*.py"
if dialog.ShowDialog() == DialogResult.OK:
    for i in dialog.FileNames:
        wkdir=os.path.dirname(i)
        os.chdir(wkdir)
        cmd='ipy64 "{}" {}'.format(pyc_path, i)  
        os.system(cmd)

    with open('dll_testbench.py', 'w') as f:
        f.writelines('import os\n')
        f.writelines('import clr\n\n')
        for i in dialog.FileNames:
            dll_basename=os.path.basename(i)[:-3]
            f.writelines('clr.AddReferenceToFileAndPath("{}")\n'.format(i[:-3]+'.dll'))
            f.writelines("import {}\n".format(dll_basename))
    os.startfile(os.path.dirname(i))