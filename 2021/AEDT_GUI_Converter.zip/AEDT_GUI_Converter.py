# coding=UTF-8
import os
import re
import sys
import clr
from collections import OrderedDict
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import DialogResult, SaveFileDialog
#self.comboBox1.Items.AddRange(Array[object](["a1","b2","c3","d4"]))
head = '''import os, clr
os.chdir(os.path.dirname(__file__))
clr.AddReference('System.Drawing')
clr.AddReference('System.Windows.Forms')

from System import Drawing, Array, ComponentModel
from System.Windows import Forms
import System.Object as object
from System.Windows.Forms import DialogResult, OpenFileDialog ,SaveFileDialog
#----------------------------------------------------------------------------
oDesktop.ClearMessages("", "", 2)
AddWarningMessage('Welcome')
image_path = os.path.join(oDesktop.GetExeDir(), 'syslib/Bitmaps/HFSS.png')


#----------------------------------------------------------------------------
class MyForm(Forms.Form):
    def __init__(self):
'''

tail = '''

form = MyForm()
form.ShowDialog()
#form.Show()
#oDesktop.PauseScript()
'''

import clr
clr.AddReference('System.Windows.Forms')
from System.Windows.Forms import Clipboard, MessageBox

input = Clipboard.GetText()

funcs = []
mapping = OrderedDict()
mapping['this.'] = 'self.'
mapping['true'] = 'True'
mapping['false'] = 'False'
mapping['System.'] = ''
mapping['Windows.'] = ''
mapping[';'] = ''
mapping['new '] = ''
mapping['//'] = '#'
mapping[', ((byte)(254))'] = ''
mapping[', ((byte)(0))'] = ''
mapping['(Drawing.FontStyle)'] = ''
mapping['(Forms.AnchorStyles)'] = ''

for line in input.splitlines():
    line = line.strip()
    if 'private void InitializeComponent()' in line:
        preprocess = []
        continue
    if '#endregion' in line:
        break
    if len(line) <= 2:
        continue
    try:
        preprocess.append(line)
    except:
        pass
   
second_process = []
temp = []   
for line in preprocess:
    if line.startswith('//'):
        second_process.append(line)
        continue        
    if line.endswith(';') and temp:
        temp.append(line)
        line = ''.join(temp)
        second_process.append(line)
        temp = []
        continue
    if not line.endswith(';'):
        temp.append(line)
        continue
    second_process.append(line)


third_process = []
for line in second_process:        
    if 'ComponentModel.ISupportInitialize' in line:
        line = '#' + line
    
    if 'ComponentModel.ComponentResourceManager' in line:
        line = '#' + line
    
    for i in mapping:
        j = mapping[i]
        line = line.replace(i, j)
    
    if 'EventHandler' in line:
        line = line.replace('EventHandler(', '').replace(')','')
        event, func = line.split('+=')
        funcs.append(func.split('.')[1])    
    
    line = re.sub('\(\(int\)\(\(\(byte\)\((\d+)\)\)\)\)', '\g<1>', line)
    line = re.sub('(\d+)F', '\g<1>', line)
    line = re.sub('(\d+)D', '\g<1>', line)
    line = re.sub('(.*)decimal\(int\[\] \{(\d+),\d+\}\)','\g<1>\g<2>', line)
    line = re.sub("(.*)\(\(Drawing.Image\).*\)", '\g<1>' + 'Drawing.Image.FromFile(image_path)', line)
    third_process.append(line)
    
result = []
for line in third_process:
    if '.AddRange' in line:
        name, data = line.split('.AddRange')        
        m = re.search('{(.*)}', data)
        datalist = m.group(1)
        for i in datalist.split(','):
            line = '{}.Add({})'.format(name, i)
            result.append(line)    
        result.append('#{}.SelectedIndex = 0'.format(name.replace('.Items', '')))
        continue

    elif line.startswith('Forms.TreeNode '):
        x = len('Forms.TreeNode ')
        line = line[x:]
        line = line.replace('Forms.TreeNode[] ', 'Array[Forms.TreeNode]')
        line = line.replace('{', '([').replace('}', '])')
        result.append(line)
    else:
        result.append(line)


text = head + '\n'.join([' '*8 + i for i in result]) + '\n'
for f in funcs:
    text+='\n    def {}(self, sender, e):\n'.format(f)
    text+=' '*8 + 'pass\n'
text += tail

dialog = SaveFileDialog()
dialog.Filter = "python files (*.py)|*.py"

if dialog.ShowDialog() == DialogResult.OK:
    with open(dialog.FileName, 'w') as f:
        f.write(text.encode('utf8'))
    os.system("start {}".format(dialog.FileName))
else:
    pass
    