# coding=UTF-8
import os
import re
import sys
import clr
import shutil
from collections import OrderedDict
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import DialogResult, SaveFileDialog

head = '''import os, clr
os.chdir(os.path.dirname(__file__))
clr.AddReference('System.Drawing')
clr.AddReference('System.Windows.Forms')

from System import Drawing, Array, ComponentModel, Diagnostics, IO
from System.Windows import Forms
import System.Object as object
import System.String as string
from System.Windows.Forms import DialogResult, OpenFileDialog ,SaveFileDialog, FolderBrowserDialog
#----------------------------------------------------------------------------
try:
    image_path = './ANSYS.png'
    oDesktop.ClearMessages("", "", 2)
    AddWarningMessage('Welcome')    
except:
    pass

#----------------------------------------------------------------------------
class MyForm(Forms.Form):
    def __init__(self):
'''

tail = '''
if __name__ == '__main__':
    form = MyForm()
    form.ShowDialog()
    form = MyForm()
    form.Dispose()
    AddWarningMessage('Good Bye!')
    #form.Show()
    #oDesktop.PauseScript()
'''

import clr
clr.AddReference('System.Windows.Forms')
from System.Windows.Forms import Clipboard, MessageBox

input = Clipboard.GetText()

funcs = []
mapping = OrderedDict()
mapping[';'] = ''
mapping['this'] = 'self'
mapping['true'] = 'True'
mapping['false'] = 'False'
mapping['null'] = 'None'
mapping['System.'] = ''
mapping['Windows.'] = ''
mapping['new '] = ''
mapping['//'] = '#'
mapping[', ((byte)(254))'] = ''
mapping[', ((byte)(0))'] = ''
mapping['(Drawing.FontStyle)'] = ''
mapping['(Forms.AnchorStyles)'] = ''
mapping['(Forms.ColumnHeader)'] = ''
mapping['(ComponentModel.ISupportInitialize)'] = ''


for line in input.splitlines():
    line = line.strip()
    if 'private void InitializeComponent()' in line:
        preprocess = []
        continue
    if '#endregion' in line:
        break
    if len(line) <= 2:
        continue
    try:
        preprocess.append(line)
    except:
        pass

try:
    preprocess
except:
    MessageBox.Show('No Valid C# Code in Clipboard!', 'AEDT GUI Converter')
    
second_process = []
temp = []   
for line in preprocess:
    if line.startswith('//'):
        second_process.append(line)
        continue        
    if line.endswith(';') and temp:
        temp.append(line)
        line = ''.join(temp)
        second_process.append(line)
        temp = []
        continue
    if not line.endswith(';'):
        temp.append(line)
        continue
    second_process.append(line)


third_process = []
for line in second_process:        
    for i in mapping:
        j = mapping[i]
        line = line.replace(i, j)
    
    if 'EventHandler' in line:
        line = line.replace('IO.FileSystemEventHandler(', '').replace(')','')
        line = line.replace('EventHandler(', '').replace(')','')
        event, func = line.split('+=')
        funcs.append(func.split('.')[1])    
    
    line = re.sub('\(\(int\)\(\(\(byte\)\((\d+)\)\)\)\)', '\g<1>', line)
    line = re.sub('(\d+)F', '\g<1>', line)
    line = re.sub('(\d+)D', '\g<1>', line)
    line = re.sub('(.*)decimal\(int\[\] \{(\d+),\d+\}\)','\g<1>\g<2>', line)
    line = re.sub("(.*)\(\(Drawing.Image\).*\)", '\g<1>' + 'Drawing.Image.FromFile(image_path)', line)
    third_process.append(line)
    
result = []
for line in third_process:
    if '.AddRange' in line:
        name, data = line.split('.AddRange')        
        m = re.search('{(.*)}', data)
        datalist = m.group(1)
        for i in datalist.split(','):
            line = '{}.Add({})'.format(name, i)
            result.append(line)    
        result.append('#{}.SelectedIndex = 0'.format(name.replace('.Items', '')))
        continue

    elif line.startswith('Forms.TreeNode '):
        x = len('Forms.TreeNode ')
        line = line[x:]
        line = line.replace('Forms.TreeNode[] ', 'Array[Forms.TreeNode]')
        line = line.replace('{', '([').replace('}', '])')
        result.append(line)
    
    elif line.startswith('ComponentModel.ComponentResourceManager '):
        x = len('ComponentModel.ComponentResourceManager ')
        line = line[x:]
        result.append('#' + line)
        
    elif line.startswith('Forms.ListViewItem '):
        x = len('Forms.ListViewItem ')
        line = line[x:]
        line = line.replace('string[] ', 'Array[string]')
        line = line.replace('{', '([').replace('}', '])')
        result.append(line)
    
    elif line.startswith('Forms.ListViewGroup '):
        x = len('Forms.ListViewGroup ')
        line = line[x:]
        result.append(line)
        
    else:
        result.append(line)


text = head + '\n'.join([' '*8 + i for i in result]) + '\n'
for f in set(funcs):
    text+='\n    def {}(self, sender, e):\n'.format(f)
    text+=' '*8 + 'pass\n'
text += tail

dialog = SaveFileDialog()
dialog.Filter = "python files (*.py)|*.py"

if dialog.ShowDialog() == DialogResult.OK:
    with open(dialog.FileName, 'w') as f:
        f.write(text.encode('utf8'))
    try:    
        target = os.path.join(os.path.dirname(dialog.FileName), 'ANSYS.png')
        shutil.copyfile('ANSYS.png', target)
    except:
        pass
    
    #os.system("ipy64 {}".format(dialog.FileName))        
    os.system("start {}".format(dialog.FileName))
else:
    pass

