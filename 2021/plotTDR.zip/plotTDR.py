import os, re, time
import matplotlib.pyplot as plt
import streamlit as st

netlist = '''
.param _SElement_Files={}
.param _SElement_Files_Index=0

* begin toplevel circuit
.model Model S TSTONEFILE="_SElement_Files[_SElement_Files_Index]"
+ INTERPOLATION=LINEAR INTDATTYP=MA HIGHPASS=10 LOWPASS=10 convolution=0 enforce_passivity=0 Noisemodel=External

A1 net_1 COMPONENT=TDR_Single_Ended RISE_TIME={} Z0={}
S2 net_1 FQMODEL="Model"

* end toplevel circuit
.TRAN {} {}
+ SWEEP 
+ _SElement_Files_Index 0 {} 1


.print TRAN V(*) O(A1,zl) 
.end'''

def createNetlist(s1p_paths):
    with open('tdr.cir', 'w') as f:
        x = '{'+','.join(['"{}"'.format(i) for i in s1p_paths])+'}'
        f.write(netlist.format(x, rise_time*1e-12, Zref, tstep*1e-12, tstop*1e-9, len(s1p_paths)-1))

    os.environ['PATH'] = 'C:\Program Files\AnsysEM\AnsysEM21.2\Win64'
    os.system('ansysedt.exe -features=beta -ng -waitforlicense -BatchSolve tdr.aedt')
    os.system('ansysedt.exe -features=beta -ng -waitforlicense -BatchExtract outputCSV.py tdr.aedt')
    
    with open('tdr.csv') as f:
        text = f.readlines()
    
    data = []
    for line in text[1:]:
        data.append(line.strip().split(','))
        time, *tdrs = zip(*data)
    
    global result
    result = []
    for zn in tdrs:
        x = []
        for t, z in zip(time, zn):
            if len(z) > 0:
                x.append((float(t), float(z)))
        result.append(x)


def plot():
    nx = 0
    c = st.columns(4)
    for nport, i in enumerate(result):
        t, z = zip(*i)
        plt.clf()
        plt.grid()
        plt.title(touchstone.name + '-Port: {}'.format(nport+1))
        plt.xlabel('time(ns)')
        plt.ylabel('Z(ohm)')        
        plt.plot(t, z, color='red')
        with c[nx%4]:
            st.pyplot(plt)
            nx += 1


def readTouchstone():
    global model
    model = []
    file_text = touchstone.getvalue().splitlines()
    global Nport
    Nport = int(touchstone.name.split('.')[-1][1:-1])

    port_dict = {}
    header = []
    
    file_text = [i.decode("utf-8", errors='ignore') for i in file_text]
    for i in file_text:
        if len(i) == 0:
            continue
        if i[0] =='!':
            header.append(i)
            try:
                m = re.search('Port\[(\d+)\]\s=\s(\S+)', i)
                port_dict[int(m.group(1))] = m.group(2)
            except:
                pass
        elif i[0] == '#':
            header.append(i)
            global label
            label = i
            _, freq_unit, mtype, mformat, _, _ = i.strip().split()

            if mtype != 'S':
                raise Exception("Can't handle {} matrix".format(mtype))
        else:
            model += [v for v in i.strip().split()]
    return model

def outputS1P():
    freq = model[0::(2*Nport*Nport+1)]

    global s1p_files
    s1p_files = []

    for n in range(Nport):
        a = model[2*Nport*n+(2*n)+1::(2*Nport*Nport+1)]
        b = model[2*Nport*n+(2*n)+2::(2*Nport*Nport+1)]
        
        s1p_path = 'p{}.s1p'.format(time.time())
        time.sleep(0.01)
        s1p_files.append(s1p_path)
        with open(s1p_path, 'w') as f:
            f.write(label + '\n')
            for i in zip(freq, a, b):
                f.write(' '.join(i) + '\n')

st.set_page_config(layout="wide")
st.title('Single Ended TDR of S Parameter File')

with st.form("my_form"):
    c1, c2, c3, c4 = st.columns(4)
    
    with c1:
        rise_time = st.number_input(label='Rise Time(ps)', value=35)
    
    with c2:
        Zref = st.number_input(label='Zref(Ohm)', value=50)
    
    with c3:
        tstep = st.number_input(label='Tstep(ps)', value=10)
    
    with c4:
        tstop = st.number_input(label='Tstop(ns)', value=5)
    
    touchstone = st.file_uploader('Upload sNp File')
    submitted = st.form_submit_button("Submit")

if submitted and touchstone:    
    with st.empty():
        twait = 0
        while(os.path.isfile('solver.lock')):
            st.subheader('Waiting Solver: {}secs'.format(twait))
            time.sleep(1)
            twait += 1
        else:
            with open('solver.lock', 'w') as f:
                pass
        
        st.subheader('Read Touchstone!')
        readTouchstone()
        
        st.subheader('OutputS1P!')        
        outputS1P()
        
        st.subheader('Run Transient!')         
        createNetlist(s1p_files)
              
        plot()
        
        for i in s1p_files:
            os.remove(i)
        os.remove('solver.lock')
    