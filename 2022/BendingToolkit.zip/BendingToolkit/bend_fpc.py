carrier_name = 'Rectangle1'

from pyaedt import Hfss
from collections import defaultdict

hfss = Hfss(specified_version='2022.1')
hfss.autosave_disable()

def wrap_sheet(sheet_name, carrier_name):
    oEditor = hfss.modeler.oeditor
    oEditor.WrapSheet(
    	[
    		"NAME:Selections",
    		"Selections:="		, '{}, {}'.format(sheet_name, carrier_name)
    	], 
    	[
    		"NAME:WrapSheetParameters",
    		"Imprinted:="		, False
    	])

def create_object_from_faces(self, faces):
    face_ids = [face.id for face in faces]
    objs = [self._find_object_from_face_id(fid) for fid in face_ids]

    varg1 = ["NAME:Selections"]
    varg1.append("Selections:="), varg1.append(','.join(objs))
    varg1.append("NewPartsModelFlag:="), varg1.append("Model")
    
    varg = []
    for face_id in face_ids:
        varg2 = ["NAME:BodyFromFaceToParameters"]
        varg2.append("FacesToDetach:="), varg2.append([face_id])
        varg.append(varg2)
    
    new_object_names = self._oeditor.CreateObjectFromFaces(varg1, ["NAME:Parameters"]+varg)
    return [self._create_object(i) for i in new_object_names]

setattr(hfss.modeler, 'create_object_from_faces', lambda x:create_object_from_faces(hfss.modeler, x))

#%%
data = defaultdict(list)
for i in hfss.modeler.object_list:
    all_z = []
    for v in i.vertices:
        x, y, z = v.position
        all_z.append(z)

    elevation = min(all_z)
    height = max(all_z) - min(all_z)
    material = i.material_name
    color = str(i.color)
    
    if material not in ['', 'air', 'vacuum']:
        data[(elevation, height, material, color)].append(i)
        
#%% 
data2 = {}
for i, obj_list in data.items():
    faces = [j.bottom_face_z for j in obj_list]
    x = hfss.modeler.create_object_from_faces(faces)
    
    if len(x) > 1:
        hfss.modeler.unite(x)
    data2[i] = x[0]

#%%
for (elevation, height, material, color), sheet in data2.items():
    wrap_sheet(sheet.name, carrier_name)
    
    z = hfss.modeler.get_object_from_name(sheet.name)
    before = [i.position for i in z.vertices]
    if elevation > 0:
        hfss.modeler.thicken_sheet(sheet.name, elevation)
        z = hfss.modeler.get_object_from_name(sheet.name)
        
        newfaces = []
        for face in z.faces:
            for vertex in face.vertices:
                if vertex.position in before:
                    break
            else:
                newfaces.append(face)

        new_objects = hfss.modeler.create_object_from_faces(newfaces)
        hfss.modeler.unite(new_objects)
        z.delete()
        
        if height:
            hfss.modeler.thicken_sheet(new_objects[0].name, height)
            new_objects[0].material_name = material
        else:
            hfss.modeler.separate_bodies([new_objects[0].name])
    else:
        hfss.modeler.thicken_sheet(sheet.name, height)
        sheet.material_name = material

hfss.logger.info('finished')
