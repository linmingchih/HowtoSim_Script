import os
import sys
from random import randrange

import clr
clr.AddReference("System.Windows.Forms")

from System.Windows.Forms import DialogResult, OpenFileDialog
dialog = OpenFileDialog()
dialog.Multiselect = True
dialog.Title = "Select S Parameter"
dialog.Filter = "text files (*.txt)|*.txt;*.s*p"

if dialog.ShowDialog() == DialogResult.OK:
    touchstone_path, config_path = dialog.FileNames
    if touchstone_path.endswith('.txt'):
        touchstone_path, config_path = config_path, touchstone_path
else:
    sys.exit()

model_name, ext = os.path.basename(touchstone_path).split('.')
spice_path = os.path.join(oDesktop.GetTempDirectory(), '{}_{}.sp'.format(model_name, randrange(1000)))
num = int(ext[1:-1])


netlist = ['.model {} S TSTONEFILE= "{}" INTERPOLATION=LINEAR INTDATTYP=MA HIGHPASS=10 LOWPASS=10 convolution=0 enforce_passivity=0 Noisemodel=External'.format(model_name, touchstone_path)]
netlist.append('.TRAN 10e-12 5e-09')


with open(config_path) as f:
    text = f.readlines()

rising_time = float(text[0])
Z0 = int(text[1])

probe = []
for line in text[2:]:
    try:
        p = line.strip().split()
        if len(p) in [1, 2]:
            probe.append([int(i) for i in p])
    except:
        pass

output = []
for i, p in enumerate(probe):
    nets = ['net_{}'.format(j) for j in range(1, num+1)]
    s_line = 'S0 {} FQMODEL="{}"'.format(' '.join(nets), model_name)
    if i > 0:
        netlist.append('\n.alter {}'.format(i))
        
    if len(p) == 2:
        m, n = p
        if m > num or n > num:
            continue
        netlist.append(s_line)
        tdr_line = 'A0 net_{0} net_{1} COMPONENT=TDR_Differential_Ended RISE_TIME={2} Z0={3}'.format(m, n, rising_time, 2*Z0)
        output.append('O(A0,zdiff)')
        
    elif len(p) == 1:
        m, = p
        if m > num:
            continue
        netlist.append(s_line)
        tdr_line = 'A0 net_{0} COMPONENT=TDR_Single_Ended RISE_TIME={1} Z0={2}'.format(m, rising_time, Z0)
        output.append('O(A0,zl)')
        
    netlist.append(tdr_line)
    for j in range(1, num+1):
        if j not in p:
            netlist.append('R{0} net_{0} 0 {1}'.format(j, Z0))        
        else:
            netlist.append('R{0} 0 0 {1}'.format(j, Z0))
            
    netlist.append('.print TRAN V(*) '+ output[-1])

with open(spice_path, 'w') as f:
    f.write('\n'.join(netlist))


if 'oDesktop' in locals():
    oDesktop.OpenProject(spice_path)
    oDesktop.ClearMessages("", "", 2)
    
    oProject = oDesktop.GetActiveProject()
    oDesign = oProject.GetActiveDesign()
    oDesign.AnalyzeAll()
    
    oModule = oDesign.GetModule("ReportSetup")
    
    oModule.CreateReport("Transient Device Properties Plot 1", "Standard", "Rectangular Plot", "TRAN", 
    	[
    		"NAME:Context",
    		"SimValueContext:="	, [1,0,2,0,False,False,-1,1,0,1,1,"",0,0,"DE",False,"0","DP",False,"500000000","DT",False,"0.001","NUMLEVELS",False,"0","WE",False,"5ns","WM",False,"5ns","WN",False,"0ps","WS",False,"0ps"]
    	], 
    	[
    		"Time:="		, ["All"]
    	], 
    	[
    		"X Component:="		, "Time",
    		"Y Component:="		, ["{}".format(output[0])]
    	])
    
    for n, i in enumerate(output[1:], 1):
        oModule.AddTraces("Transient Device Properties Plot 1", "TRAN_{}".format(n).replace(',', ':'), 
        	[
        		"NAME:Context",
        		"SimValueContext:="	, [1,0,2,0,False,False,-1,1,0,1,1,"",0,0,"DE",False,"0","DP",False,"500000000","DT",False,"0.001","NUMLEVELS",False,"0","WE",False,"5ns","WM",False,"5ns","WN",False,"0ps","WS",False,"0ps"]
        	], 
        	[
        		"Time:="		, ["All"]
        	], 
        	[
        		"X Component:="		, "Time",
        		"Y Component:="		, ["{}".format(output[n]).replace(',', ':')]
        	])