# -*- coding: utf-8 -*-
info = r'''
在AEDT當中執行本腳本之後，跳出檔案選擇視窗，先選S參數，再選config.txt，即可根據配置輸出TDR Report

config.txt第一行為Trise, 第二行為Z0，之後為port編號, 兩個數字為接差分TDR，一個數字為接單端TDR
------------------
10e-12
50
1 2
2 3
3 1
4
------------------
'''
AddWarningMessage(info)

import os
import sys
from random import randrange

import clr
clr.AddReference("System.Windows.Forms")

from System.Windows.Forms import DialogResult, OpenFileDialog
dialog = OpenFileDialog()
dialog.Multiselect = True
dialog.Title = "Select S Parameter"
dialog.Filter = "text files (*.txt)|*.txt;*.s*p"

if dialog.ShowDialog() == DialogResult.OK:
    touchstone_path, config_path = dialog.FileNames
    if touchstone_path.endswith('.txt'):
        touchstone_path, config_path = config_path, touchstone_path
else:
    sys.exit()

model_name, ext = os.path.basename(touchstone_path).split('.')
spice_path = os.path.join(oDesktop.GetTempDirectory(), '{}_{}.sp'.format(model_name, randrange(1000)))
num = int(ext[1:-1])


netlist = ['.model {} S TSTONEFILE= "{}" INTERPOLATION=LINEAR INTDATTYP=MA HIGHPASS=10 LOWPASS=10 convolution=0 enforce_passivity=0 Noisemodel=External'.format(model_name, touchstone_path)]

with open(config_path) as f:
    text = f.readlines()

rising_time = float(text[0])
Z0 = int(text[1])

probe = []
for line in text[2:]:
    try:
        p = line.strip().split()
        if len(p) in [1, 2]:
            probe.append([int(i) for i in p])
    except:
        pass

output = []
for i, p in enumerate(probe):
    nets = ['net_{}_{}'.format(i,j) for j in range(1, num+1)]
    s_line = 'S{} {} FQMODEL="{}"'.format(i, ' '.join(nets), model_name)
    
    if len(p) == 2:
        m, n = p
        if m > num or n > num:
            continue
        netlist.append(s_line)
        tdr_line = 'A{0} net_{0}_{1} net_{0}_{2} COMPONENT=TDR_Differential_Ended RISE_TIME={3} Z0={4}'.format(i, m, n, rising_time, 2*Z0)
        output.append('O(A{0},zdiff)'.format(i))
        
    elif len(p) == 1:
        m, = p
        if m > num:
            continue
        netlist.append(s_line)
        tdr_line = 'A{0} net_{0}_{1} COMPONENT=TDR_Single_Ended RISE_TIME={2} Z0={3}'.format(i, m, rising_time, Z0)
        output.append('O(A{0},zl)'.format(i))
        
    netlist.append(tdr_line)
    for j in range(1, num+1):
        if j not in p:
            netlist.append('R{0}_{1} net_{0}_{1} 0 {2}'.format(i, j, Z0))        
    
netlist.append('.TRAN 10e-12 5e-09')
netlist.append('.print TRAN V(*) '+' '.join(output))

with open(spice_path, 'w') as f:
    f.write('\n'.join(netlist))

if 'oDesktop' in locals():
    oDesktop.OpenProject(spice_path)
    oDesktop.ClearMessages("", "", 2)
    
    oProject = oDesktop.GetActiveProject()
    oDesign = oProject.GetActiveDesign()
    oDesign.AnalyzeAll()

    oModule = oDesign.GetModule("ReportSetup")
    oModule.CreateReport("Transient Device Properties Plot 1", "Standard", "Rectangular Plot", "TRAN", 
    	[
    		"NAME:Context",
    		"SimValueContext:="	, [1,0,2,0,False,False,-1,1,0,1,1,"",0,0,"DE",False,"0","DP",False,"500000000","DT",False,"0.001","NUMLEVELS",False,"0","WE",False,"10ns","WM",False,"10ns","WN",False,"0ps","WS",False,"0ps"]
    	], 
    	[
    		"Time:="		, ["All"]
    	], 
    	[
    		"X Component:="		, "Time",
    		"Y Component:="		, [i.replace(',', ':') for i in output]
    	])