config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.5/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Forms import OpenFileDialog, DialogResult    
    from System.Windows.Controls import ListBoxItem
    os.chdir(os.path.dirname(__file__))
'''
exec(config)
#Functions---------------------------------------------------------------------|



    
#GUI---------------------------------------------------------------------------|
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'AEDT_Archive_All.xaml')
        

    def aedt_tb_TextChanged(self, sender, e):
        pass
   
    def aedt_tb_MouseDoubleClick(self, sender, e):
        dialog = OpenFileDialog()
        dialog.Filter = "AEDT files(*.aedt)|*.aedt"
        dialog.Multiselect = True
        if dialog.ShowDialog() == DialogResult.OK:
            for i in dialog.FileNames:
                self.aedt_tb.Text+=i+'\n'
    
    def Button_Click(self, sender, e):
        self.aedt_tb.Text=''

    
    def archive_bt_Click(self, sender, e):
        oDesktop.ClearMessages('','',2)
        for i in self.aedt_tb.Text.splitlines():    
            try:
                oProject=oDesktop.OpenProject(i)
                oProject.SaveProjectArchive(i+'z', self.IncludeExternalFiles_cb.IsChecked, self.IncludeResultsFiles_cb.IsChecked,[],'')
                oDesktop.CloseProject(os.path.basename(i.split('.')[0]))   
                AddWarningMessage('Succeessful archived {}.'.format(i))
            except:
                AddWarningMessage('Failed to archive {}.'.format(i))
        
        self.aedt_tb.Text=''

#Code End----------------------------------------------------------------------|       
MyWindow().ShowDialog()

