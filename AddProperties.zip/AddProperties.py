# ----------------------------------------------
# Script Recorded by ANSYS Electronics Desktop Version 2020.1.0
# 19:42:34  Mar 13, 2020
# ----------------------------------------------
import re
import clr
clr.AddReference("System.Windows.Forms")
clr.AddReference("System.Drawing")
from System.Windows.Forms import DialogResult, OpenFileDialog

import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()

oDesktop.ClearMessages("","",2)

dialog = OpenFileDialog()
dialog.Filter = "variable file (*.csv)|*.csv"

if dialog.ShowDialog() == DialogResult.OK:
    with open(dialog.FileName) as f:
        data = f.readlines() 

def variable(name, value):
    return [
        "NAME:{}".format(name),
        "PropType:="		, "VariableProp",
        "UserDef:="		, True,
        "Value:="		, "{}".format(value)
    ]

def separator(name):
    return [
        "NAME:{}".format(name),
        "PropType:="		, "SeparatorProp",
        "UserDef:="		, True,
        "Value:="		, ""
    ]
def array_index(name):
    return [
        "NAME:{}".format(name+'_index'),
        "PropType:="		, "ArrayIndexVariableProp",
        "UserDef:="		, True,
        "Value:="		, "0",
        "ArrayVarName:="	, "{}_array".format(name)
    ]
    
def changeProp(prop):
    oDesign.ChangeProperty(
        [
            "NAME:AllTabs",
            [
                "NAME:LocalVariableTab",
                [
                    "NAME:PropServers", 
                    "LocalVariables"
                ],
                [
                    "NAME:NewProps", prop

                ]
            ]
        ])

for i in data:
    if len(i.strip())==0:
        continue
    x=[j for j in i.strip().split(',')]
    if len(x)==0 or len(x)==2:
        continue
    if len(x)==1:
        name=x[0]
        changeProp(separator(name))
        continue
    if len(x)==3:
        name, unit, value = x
        changeProp(variable(name, value+unit))
        continue
    if len(x)>3:
        name=x[0]
        unit=x[1]
        changeProp(variable(name+'_array', '[{}]{}'.format(','.join(x[2:]),unit)))
        changeProp(array_index(name))
