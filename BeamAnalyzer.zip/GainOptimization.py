# -*- coding: utf-8 -*-
"""
Created on Sat Apr 20 03:42:15 2019

@author: Lin, Ming Chih
"""
from numpy import loadtxt, sin, cos, log, zeros, radians, power, sqrt
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize as optimize
import os, time, json
from collections import OrderedDict

class farfield():
    def __init__(self, filename='', data=None):
        self.Ntheta = 181
        self.Nphi = 361

        if filename is not '':
            self.data = loadtxt(filename, delimiter=' ', skiprows=4)
        elif data is not None:
            self.data=data
        else:
            self.data=zeros((self.Ntheta*self.Nphi, 4))
            
        self._computeGain()
    
    def __add__(self, other):
        return farfield(data=self.data+other.data)
    
    def shiftPhase(self, angle):
        angle_r=radians(angle)
        rotated=zeros(self.data.shape)
        
        rotated[:,0]=self.data[:,0]*cos(angle_r)-self.data[:,1]*sin(angle_r)
        rotated[:,1]=self.data[:,0]*sin(angle_r)+self.data[:,1]*cos(angle_r)
        rotated[:,2]=self.data[:,2]*cos(angle_r)-self.data[:,3]*sin(angle_r)
        rotated[:,3]=self.data[:,2]*sin(angle_r)+self.data[:,3]*cos(angle_r)
        
        return farfield(data=rotated)
    
    def _computeGain(self):
        p=np.sum(power(self.data, 2), axis=1)
        dth=np.repeat(range(self.Ntheta),self.Nphi)
        self.ds=radians(1)*radians(1)*sin(radians(dth))
        s=sum(self.ds)
        self.gain=p/(np.sum(self.ds*p)/s)
    
    def getGain(self, theta, phi):        
        return self.gain[theta*self.Nphi+phi]
    
    def getE(self, theta, phi):
        E=self.data[theta*self.Nphi+phi]
        return phasor(E[0], E[1]), phasor(E[2],E[3])
    
class phasor():
    def __init__(self, x0, y0):
        self.x0=x0
        self.y0=y0
    
    def __str__(self):
        return f'{self.x0}, {self.y0}'
    
    def rotate(self, angle):
        _angle=radians(angle)
        x1=self.x0*cos(_angle)-self.y0*sin(_angle)
        y1=self.x0*sin(_angle)+self.y0*cos(_angle)
        return phasor(x1, y1)
    
    def __add__(self, other):
        x1=self.x0 + other.x0
        y1=self.y0 + other.y0
        return phasor(x1, y1)
    
    def mag(self):
        return sqrt(self.x0*self.x0+self.y0*self.y0)     

def factory(ffds, theta, phi):
    def weighting(x):
        U, V=phasor(0,0), phasor(0,0)
        for i, j in zip(ffds,x):
            U+=i.getE(theta, phi)[0].rotate(j)
            V+=i.getE(theta, phi)[1].rotate(j)
        return -sqrt(power(U.mag(),2)+power(V.mag(),2)) 
    return weighting

   
if __name__ == '__main__':    
    #Input path of far fiels to compute below
    ffd_path=r'D:\demo3\70000000000'
    ffd_files=[file for file in os.listdir(ffd_path) if file.endswith(".ffd")]
    dtheta, dphi=15, 15
    export_name='democase'
    #end
    
    tstart=time.time()
    ffds=[farfield(f'{ffd_path}/{i}') for i in ffd_files]
    
    phase_table=OrderedDict()

    initial_guess=[0]*len(ffds)
    
    for i in range(0, 180+dtheta, dtheta):
        for j in range(0, 360+dphi, dphi):
            if (i==0 and j!=0) or (i==180 and j!=0):
                continue
            print(f'Computing:{i},{j}.\n')
            weighting=factory(ffds, i, j)
            result= optimize.minimize(weighting, initial_guess)
            
            ffdsum=farfield()
            if result.success:
                initial_guess=result.x
                for k, m in zip(ffds, result.x):
                    ffdsum+=k.shiftPhase(m)
                maxGain=ffdsum.getGain(i,j)    
                phase_table[f'{i},{j}']=(list(result.x), maxGain)
            else:
                phase_table[(i,j)]='Optimization Failed'
    
    with open(f'{ffd_path}/{export_name}.json', 'w') as fp:
        portnames=[i[:-4] for i in ffd_files]
        json.dump((portnames, phase_table), fp, indent=4)
            