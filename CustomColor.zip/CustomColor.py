config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Controls import ListBoxItem
    os.chdir(os.path.dirname(__file__))
'''
exec(config)
#Functions---------------------------------------------------------------------|



    
#GUI---------------------------------------------------------------------------|
from System.Windows.Media import SolidColorBrush, Color

class MyWindow(Window):

    def __init__(self):
        wpf.LoadComponent(self, 'CustomColor.xaml')
        self.cb=[self.c0, self.c1, self.c2, self.c3, self.c4, self.c5, self.c6, self.c7]
        self.cb+=[self.c8, self.c9, self.c10, self.c11, self.c12, self.c13, self.c14, self.c15]
        
    def TextBox_TextChanged(self, sender, e):

        for i in self.cb:
            i.Fill=SolidColorBrush(Color.FromArgb(255, 255, 255, 255));

        import re
        m=re.findall('[0-9A-Fa-f]{6}',self.tb_input.Text)
        x=[i[4:6]+i[2:4]+i[0:2] for i in m]+['FFFFFF']*16
        try:
            code=[(int(i[0:2],16), int(i[2:4],16), int(i[4:6],16)) for i in m]
        except:
            pass

        for i,c in zip(self.cb, code):
            i.Fill=SolidColorBrush(Color.FromArgb(255, c[0], c[1], c[2]));

        self.tb_code.Text=' '.join([str(int(i, 16)) for i in x][0:16])
        

#Code End----------------------------------------------------------------------|       
MyWindow().ShowDialog()

