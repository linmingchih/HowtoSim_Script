import wpf
import clr, re
import zipfile
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import DialogResult, OpenFileDialog, MessageBox
from System.Windows import Application, Window

class config():
    def __init__(self, xmlfile):
        self.xml=xmlfile
        self.pattern='<VALUE ObjectName="DFavorites" Value="(.*?)"'
        self.replace=lambda x:'<VALUE ObjectName="DFavorites" Value="{}"'.format(x)
        
    def readFavorite(self):
        with open(self.xml, 'r') as f:
            self.text=f.read()
            m=re.search(self.pattern, self.text)
            data=m.group(1)
            return data.replace(';','\n')
    
    def writeFavorite(self, reorg_text):
        update=';'.join([i.strip() for i in reorg_text.splitlines() if len(i.strip())>0])
        print(update)
        newxml=re.sub(self.pattern, self.replace(update), self.text)
        with open(self.xml, 'w') as f:
            f.write(newxml)
            
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'FavoriteManager.xaml')

    def bt_open_Click(self, sender, e):
        dialog = OpenFileDialog()
        dialog.Filter = "XML files (*.xml)|*.xml"
        
        if dialog.ShowDialog() == DialogResult.OK:
            self.conf=config(dialog.FileName)
            self.tb_favorite.Text = self.conf.readFavorite()

    
    def bt_save_Click(self, sender, e):
        try:
            self.conf.writeFavorite(self.tb_favorite.Text)
            self.tb_favorite.Text="Successful"
        except:
            self.tb_favorite.Text="Failed"



if __name__ == '__main__':
    Application().Run(MyWindow())
