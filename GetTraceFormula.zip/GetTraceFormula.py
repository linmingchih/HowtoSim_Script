config='''import os, sys, re, clr, math
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Controls import ListBoxItem
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

#Functions---------------------------------------------------------------------|
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oEditor = oDesign.SetActiveEditor("3D Modeler")
unit=oEditor.GetModelUnits()

class line():
    def __init__(self, v0, v1):
        self.v0=v0
        self.v1=v1
        self.l=[v1[0]-v0[0],v1[1]-v0[1],v1[2]-v0[2]]   
        self.length=math.sqrt(sum([i*i for i in self.l]))

    def _move(self, dl):
        if dl>self.length:
            return False
        
        v0, v1=self.v0, self.v1
        t=dl/self.length
        
        v0=(v0[0]+t*self.l[0], v0[1]+t*self.l[1], v0[2]+t*self.l[2])
        self.v0=v0
        self.l=[v1[0]-v0[0],v1[1]-v0[1],v1[2]-v0[2]]
        self.length=math.sqrt(sum([i*i for i in self.l])) 
        return True
    
    def getLoc(self, dl, offset):
        result=[]
        if self._move(offset):
            result.append(self.v0)
        else:
            return result, round(self.length,15)
        
        while self._move(dl):
            result.append(self.v0)
        else:
            return result, round(self.length,15)

def getLocations(x, dl):
    results=[]
    surplus=dl
    for i in range(len(x)-1):
        y=line(x[i], x[i+1])
        locs, surplus=y.getLoc(dl, dl-surplus)
        results+=locs
    
    return results
    
def polylinePoints(pline):
    points=[]
    for i in oEditor.GetVertexIDsFromObject(pline):
        u=oEditor.GetVertexPosition(i)
        points.append([float(u[0]),float(u[1]),float(u[2])])
    p0=points[0]
    points=[[i[0], i[1], i[2]] for i in points[0:]]
    return points
        
        
def getParameterizedXYZ(points, para='t'):
    lenlist=[]
    x0,y0,z0=points[0]
    for x1,y1,z1 in points[1:]:
        lenlist.append(math.sqrt((x1-x0)*(x1-x0)+(y1-y0)*(y1-y0)+(z1-z0)*(z1-z0)))
        x0,y0,z0=x1,y1,z1
    lentotal=sum(lenlist)
    temp=0
    t=[0.0]

    for i in lenlist:
        temp+=i 
        t.append(temp/lentotal)
        
    cond='if({6}<{0},({1}{5})+({2}{5})*({6}-{3})/{4},{{}})'
    str=['{}','{}','{}']
    for j in range(3):
        for i in range(len(t)-2):

            temp1=cond.format(t[i+1], points[i][j],(points[i+1][j]-points[i][j]),t[i],t[i+1]-t[i],unit,para)
            str[j]=str[j].format(temp1)
        temp2='({0}{4})+({1}{4})*({5}-{2})/{3}'.format(points[i+1][j],(points[i+2][j]-points[i+1][j]),t[i+1],t[i+2]-t[i+1],unit,para)
        str[j]=str[j].format(temp2)

    return ','.join(str)


    
#GUI---------------------------------------------------------------------------|
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'GetTraceFormula.xaml')
        self.run()
        
    def TextBox_TextChanged(self, sender, e):
        self.run()
    
    def run(self):
        selected_path=oEditor.GetSelections()[0]
        points=polylinePoints(selected_path)
        self.tb_formula.Text=str(getParameterizedXYZ(points, self.tb_para.Text)) 
    


        

#Code End----------------------------------------------------------------------|       
MyWindow().ShowDialog()

