import time
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oEditor = oDesign.SetActiveEditor("Layout")
tstart=time.time()
for i in range(1,1001):
    oEditor.ChangeProperty(
        [
            "NAME:AllTabs",
            [
                "NAME:BaseElementTab",
                [
                    "NAME:PropServers", 
                    "bondwire_{}".format(i)
                ],
                [
                    "NAME:ChangedProps",
                    [
                        "NAME:Start Layer",
                        "Value:="		, "METAL-1"
                    ]
                ]
            ]
        ])
    oEditor.ChangeProperty(
        [
            "NAME:AllTabs",
            [
                "NAME:BaseElementTab",
                [
                    "NAME:PropServers", 
                    "bondwire_{}".format(i)
                ],
                [
                    "NAME:ChangedProps",
                    [
                        "NAME:End Layer",
                        "Value:="		, "METAL-2"
                    ]
                ]
            ]
        ])
    oEditor.ChangeProperty(
        [
            "NAME:AllTabs",
            [
                "NAME:BaseElementTab",
                [
                    "NAME:PropServers", 
                    "bondwire_{}".format(i)
                ],
                [
                    "NAME:ChangedProps",
                    [
                        "NAME:Material",
                        "Value:="		, "\"lead\""
                    ]
                ]
            ]
        ])
    oEditor.ChangeProperty(
        [
            "NAME:AllTabs",
            [
                "NAME:BaseElementTab",
                [
                    "NAME:PropServers", 
                    "bondwire_{}".format(i)
                ],
                [
                    "NAME:ChangedProps",
                    [
                        "NAME:PathWidth",
                        "Value:="		, "0.5mm"
                    ]
                ]
            ]
        ])
ttotal=time.time()-tstart
AddWarningMessage(str(ttotal))