config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Forms import OpenFileDialog, SaveFileDialog, DialogResult
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

def snpGenerator(touchstonePath, Z, lossDB, Floss, Fstop, Fstep, delay):
    fileName=touchstonePath
    
    freq=range(0, int(Fstop)+1, int(Fstep))
    loss=[i*(lossDB/(Floss/Fstep)) for i in range(len(freq))]
    totalPhase=delay*Fstop*360
    phase=[-i*(totalPhase/(len(freq)-1)) for i in range(len(freq))]
    
    with open(fileName, 'w') as tsf:
        tsf.writelines('# Hz S DB R {}\n'.format(Z))
        if '.s2p' in touchstonePath:
            for f, l, p in zip(freq, loss, phase):
                line='{f} -1000 0 {l} {p} {l} {p} -1000 0\n'.format(f=f, l=l, p=p)
                tsf.writelines(line)
        elif 's4p' in touchstonePath:
            for f, l, p in zip(freq, loss, phase):
                line='{f:<12} -1000 0 -1000 0 {l} {p} -1000 0\n'.format(f=f, l=l, p=p)
                line+='{f:<12} -1000 0 -1000 0 -1000 0 {l} {p} \n'.format(f=' ', l=l, p=p)
                line+='{f:<12} {l} {p} -1000 0 -1000 0 -1000 0\n'.format(f=' ', l=l, p=p)
                line+='{f:<12} -1000 0 {l} {p} -1000 0 -1000 0\n'.format(f=' ', l=l, p=p)
                tsf.writelines(line)
#Code Start-----------------------------------
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'Ideal_Channel.xaml')
        
    def save_Click(self, sender, e):
        z0=int(self.z0.Text)
        loss=-1*float(self.loss.Text)
        floss=float(self.floss.Text)*1e9 
        fstep=float(self.fstep.Text)*1e9        
        fstop=float(self.fstop.Text)*1e9 
        delay=float(self.delay.Text)*1e-9 

        ext='s2p' if self.s2p.IsChecked else 's4p'
        dialog = SaveFileDialog()   
        dialog.Filter = "Touchstone File(*.{0})|*.{0}".format(ext)
        dialog.FileName='_{}dB_loss_at_{}GHz'.format(self.loss.Text,self.floss.Text)
        if dialog.ShowDialog() == DialogResult.OK:
            snpGenerator(dialog.FileName, z0, loss, floss, fstop, fstep, delay)
            AddInfoMessage('{} is saved!'.format(dialog.FileName))
        else:
            pass

        
        
        
        
        

#Code End-------------------------------------        
MyWindow().ShowDialog()

