config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Controls import ListBoxItem
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oEditor = oDesign.SetActiveEditor("3D Modeler")

def getsortedObjects():
    totalobjects = oEditor.GetNumObjects()
    data=[]
    for i in range(totalobjects):
        objectname = oEditor.GetObjectName(i)
        faces=oEditor.GetFaceIDs(objectname)
        area=0
        for j in faces:
            area+=float(oEditor.GetFaceArea(j))
        data.append((objectname, area))
    return sorted(data, key=lambda tup: tup[1])[::-1]
    
#Code Start-----------------------------------
class MyWindow(Window):
    def __init__(self):
        oEditor.FitAll()
        wpf.LoadComponent(self, 'Object_Sort.xaml')
        for i in getsortedObjects():
            x=ListBoxItem()
            x.Content='{}: {}'.format(*i)
            self.object_LB.Items.Add(x)

    
    def Model_BT_Click(self, sender, e):
        for item in self.object_LB.SelectedItems:
            i=item.Content.split(':')[0]
            oEditor.SetPropertyValue("Geometry3DAttributeTab", i, "Model", True)            
            oEditor.SetPropertyValue("Geometry3DAttributeTab", i, "Display Wireframe", False)  
    
    def nonModel_BT_Click(self, sender, e):
        for item in self.object_LB.SelectedItems:
            i=item.Content.split(':')[0]
            oEditor.SetPropertyValue("Geometry3DAttributeTab", i, "Model", False)
            oEditor.SetPropertyValue("Geometry3DAttributeTab", i, "Display Wireframe", True)             
        

#Code End-------------------------------------        
MyWindow().ShowDialog()

