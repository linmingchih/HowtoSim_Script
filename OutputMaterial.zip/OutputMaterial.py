config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Controls import ListBoxItem
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

def getMaterials(aedt_file):
    text=[]
    try:
        with open(aedt_file) as f:
            for i in f:
                text.append(i)
    except:
        pass
            
    for n, i in enumerate(text):
        if "$begin 'Materials'" in i:
            n0=n
            continue
        if "$end 'Materials'" in i:
            n1=n
            break
    material=text[n0+1:n1]
    x=[]
    for n, i in enumerate(material):
        if i.startswith('\t\t\t$begin'):
            x.append(n)
            continue
        if i.startswith('\t\t\t$end'):
            x.append(n)
            
    mat=[material[m:n] for m,n in zip(x[0::2],x[1::2])]
    result=[]
    for i in mat:
        dk, df, cond='None', 'None', 'None'
        name=re.search("'(.*)'",i[0]).group(1)
        for j in i[1:]:
            if '\t\t\t\tpermittivity' in j:
                dk=re.search("'(.*)'",j).group(1)
            if '\t\t\t\tdielectric_loss_tangent' in j:
                if dk=='dielectric_loss_tangent':
                    break
                df=re.search("'(.*)'",j).group(1)
            if '\t\t\t\tconductivity' in j:
                cond=re.search("'(.*)'",j).group(1)
        
        if (dk, df, cond)==('None','None','None'):
            break
        else:
            result.append((name, dk, df, cond))
        
    return str(result)
    
#Functions---------------------------------------------------------------------|
clr.AddReference("System.Windows.Forms")
from System.Windows.Forms import OpenFileDialog, DialogResult
dialog = OpenFileDialog()
dialog.Filter = "AEDT files(*.aedt)|*.aedt"
dialog.Multiselect = True
if dialog.ShowDialog() == DialogResult.OK:
    oDesktop.ClearMessages('','',2)
    for i in dialog.FileNames:
        try:
            AddWarningMessage(i)
            AddWarningMessage(str(getMaterials(i)))
        except:
            AddWarningMessage("Failed")
    
#GUI---------------------------------------------------------------------------|


#Code End----------------------------------------------------------------------|       


