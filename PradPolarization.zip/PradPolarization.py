config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Forms import OpenFileDialog, DialogResult    
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

import collections
from math import radians, sin, cos, pi, sqrt
def split(x, conf=float):
    return list(map(conf, x.split()))

class polPower():
    def __init__(self, ffdfile):
        with open(ffdfile) as f:
            text=f.readlines()
            
        theta_start, theta_stop, theta_points=split(text[0], int)
        dtheta=int((theta_stop-theta_start)/(theta_points-1))
        self.theta_range=list(range(theta_start, theta_stop+dtheta, dtheta))
        self.dtheta=dtheta
        
        phi_start, phi_stop, phi_points=split(text[1], int)    
        dphi=int((phi_stop-phi_start)/(phi_points-1))
        self.phi_range=list(range(phi_start, phi_stop+dphi, dphi))
        self.dphi=dphi
        self.phi_start=phi_start
        self.phi_points=phi_points
        
        self.data=collections.OrderedDict()
        freq=''
        
        for i in text[3:]:
            if i.startswith('Frequency'):
                freq=i.strip().split(' ')[1]
                self.data[freq]=[]
            else:
                self.data[freq].append(i)

    def compute(self, path):
        with open(path+'/PradPolarization.csv','w') as f:
            f.writelines('freq, Ptheta, Pphi, Ptotal\n')    
            for i in self.data:
                Ptheta, Pphi, Ptotal=self.calculate(self.data[i])
                f.writelines(','.join([i, str(Ptheta), str(Pphi), str(Ptotal)])+'\n')
                
     
    
    def calculate(self, text):    
        data=[split(i) for i in text]
    
        p_theta=list(map(lambda x:sum([i*i/377/2 for i in x[0:2]]), data))
        p_phi=list(map(lambda x:sum([i*i/377/2 for i in x[2:4]]), data))
    
        area=lambda x:radians(self.dtheta)*radians(self.dphi)*sin(radians(x))
    
        Ptheta, Pphi=0, 0
        A=0
        for theta in self.theta_range:
            for phi in self.phi_range:

                if phi>=self.phi_start+360:
                    continue
                A+=area(theta)
                i=int(theta/self.dtheta*self.phi_points+phi/self.dphi)
                Ptheta+=area(theta)*p_theta[i]
                Pphi+=area(theta)*p_phi[i]
    
        Prad=Ptheta+Pphi
        return (Ptheta, Pphi, Prad)
 
#Code Start-----------------------------------
dialog = OpenFileDialog()
dialog.Title='Prad per Polarization'
dialog.Filter = "HFSS far field files (*.ffd)|*.ffd"

if dialog.ShowDialog() == DialogResult.OK:
    x=polPower(dialog.FileName)
    x.compute(os.path.dirname(dialog.FileName))

 