config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.5/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Controls import ListBoxItem
    os.chdir(os.path.dirname(__file__))
'''
exec(config)
#Functions---------------------------------------------------------------------|
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
folderpath=oProject.GetPath()
oDesign = oProject.GetActiveDesign()
oModule = oDesign.GetModule("BoundarySetup")
ports=[i.split(':')[0] for i in oModule.GetExcitations()[::2]]
combination=['{},{}'.format(i,j) for i in ports for j in ports]  

def getmatches(pattern='element(\d+)_Bump_H1,element\1_Bump_H1'):
    text=r'{}'.format(pattern)
    pattern=re.compile(text)
    matches=[]
    for i in combination:
        m=re.search(pattern, i)
        if m:
            matches.append(m.group(0))
        else:
            continue
    return matches

def exportpng(formula):   
    oModule = oDesign.GetModule("ReportSetup")
    oModule.CreateReport("temp", "Modal Solution Data", "Rectangular Plot", "Setup1 : Sweep", 
        [
            "Domain:="		, "Sweep"
        ], 
        [
            "Freq:="		, ["All"],
            "patchW:="		, ["Nominal"],
            "patchL:="		, ["Nominal"],
            "patch2L:="		, ["Nominal"],
            "patch2W:="		, ["Nominal"],
            "top_patch_offset:="	, ["Nominal"],
            "subW:="		, ["Nominal"],
            "subL:="		, ["Nominal"],
            "bot_patch_offset:="	, ["Nominal"],
            "feed_Xpos:="		, ["Nominal"],
            "feed_Ypos:="		, ["Nominal"],
            "cond_T:="		, ["Nominal"],
            "feed_via_rad:="	, ["Nominal"],
            "feed_subH:="		, ["Nominal"],
            "antipad_rad:="		, ["Nominal"],
            "yposition:="		, ["Nominal"],
            "beamID:="		, ["Nominal"],
            "_y:="			, ["Nominal"]
        ], 
        [
            "X Component:="		, "Freq",
            "Y Component:="		, [formula]
        ], [])
    png_path="{}/{}.png".format(folderpath, formula)
    oModule.ExportImageToFile("temp", png_path,1024, 768)
    AddWarningMessage("Exported:{}".format(png_path))
    oModule.DeleteReports(["temp"])    

    
def exportS(Z0):
    oModule = oDesign.GetModule("Solutions")
    oModule.ExportNetworkData("", ["Setup1:Sweep"], 3, "{}/model.s{}p".format(folderpath, len(ports)), 
	[
"All"
	], True, Z0, "S", -1, 0, 15, True, True, False)    
    
#GUI---------------------------------------------------------------------------|
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'RegexPair.xaml')
        self.regex_tb.Text='.*'
        self.formula_tb.Text='dB, S'
        
    def regex_tb_TextChanged(self, sender, e):
        try:
            self.match=getmatches(sender.Text)
            self.matched_tb.Text='\n'.join(self.match)
        except:
            self.matched_tb.Text=''
            self.cascade_tb.Text=''
        try:
            x,y=self.formula_tb.Text.split(',')
            self.cascade_tb.Text=';'.join(["{}({}({}))".format(x.strip(), y.strip(), i) for i in self.match])
        except:
            pass
    def exportS_bt_Click(self, sender, e):
        try:
            z0=int(self.Z0_tb.Text)
            exportS(z0)
            oDesktop.ClearMessages('','',2)
            AddWarningMessage("Exported:{}/model.s{}p".format(folderpath, len(ports)))
        except:
            AddWarningMessage("Export Failed!")
    
    def exportPNG_bt_Click(self, sender, e):
        for i in self.cascade_tb.Text.split(';'):
            exportpng(i)
            
        
    def formula_tb_TextChanged(self, sender, e):
        try:
            x,y=self.formula_tb.Text.split(',')
            x=x.strip()
            y=y.strip()
            if x=='':
                self.formulas=["{}({})".format(y, i) for i in self.match]
                self.cascade_tb.Text=';'.join(self.formulas)
            else:
                self.formulas=["{}({}({}))".format(x, y, i) for i in self.match]
                self.cascade_tb.Text=';'.join(self.formulas)
        except:
            self.cascade_tb.Text=''
        
        
#Code End----------------------------------------------------------------------|       
MyWindow().ShowDialog()

