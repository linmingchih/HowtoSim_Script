config='''import os, sys, re, clr
from math import log, sqrt, exp
aedt_path='C:/Program Files/AnsysEM/AnsysEM19.3/Win64'
dll_dir=aedt_path+'/common/IronPython/DLLs'
sys.path.append(dll_dir)
clr.AddReference('IronPython.Wpf')
import wpf
from System.Windows import Window

sys.path.append(aedt_path)
sys.path.append(aedt_path + '/PythonFiles/DesktopPlugin')
import ScriptEnv
ScriptEnv.Initialize('Ansoft.ElectronicsDesktop')
'''
exec(config)

class createDiff():
    def __init__(self, oDesktop):
        oProject = oDesktop.NewProject()
        oProject.InsertDesign("HFSS", "HFSSDesign1", "DrivenModal", "")
        self.oProject = oDesktop.GetActiveProject()
        self.oDesign = self.oProject.GetActiveDesign()
        self.oEditor = self.oDesign.SetActiveEditor("3D Modeler")
        self.oEditor.SetModelUnits(["NAME:UnitsParameter","Units:=","mil","Rescale:=",False])
        self.unit='mil'

        self.AddCopper()
        self.objectName=[]
  
    def AddCopper(self):
        oDefinitionManager = self.oProject.GetDefinitionManager()
        if not oDefinitionManager.DoesMaterialExist("copper"):
            oDefinitionManager.EditMaterial("copper",["NAME:copper","CoordinateSystemType:=","Cartesian","BulkOrSurfaceType:=",1,["NAME:PhysicsTypes","set:=",["Electromagnetic","Thermal","Structural"]],["NAME:AttachedData",["NAME:MatAppearanceData","property_data:=","appearance_data","Red:=",242,"Green:=",140,"Blue:=",102]],"permeability:=","0.999991","conductivity:=","58000000","thermal_conductivity:=","400","mass_density:=","8933","specific_heat:=","385","youngs_modulus:=","120000000000","poissons_ratio:=","0.38","thermal_expansion_coeffcient:=","1.77e-05"])

    def AddMaterial(self, dk):
        oDefinitionManager = self.oProject.GetDefinitionManager()
        x=oDefinitionManager.AddMaterial(["NAME:material","CoordinateSystemType:=","Cartesian","BulkOrSurfaceType:=",1,["NAME:PhysicsTypes","set:=",["Electromagnetic"]],"permittivity:=",str(dk)])
        
        return x
            
    def createBox(self, name, origin, size, material='"vacuum"', solveInside=True, color="(255 128 64)"):
        origin=tuple(str(i)+self.unit for i in origin)
        size=tuple(str(i)+self.unit for i in size)
        
        x=self.oEditor.CreateBox(["NAME:BoxParameters","XPosition:=", origin[0],"YPosition:=", origin[1],"ZPosition:=", origin[2],"XSize:=",size[0],"YSize:=",size[1],"ZSize:=",size[2]],["NAME:Attributes","Name:=", name,"Flags:=","","Color:=",color,"Transparency:=",0.5,"PartCoordinateSystem:=",'Global',"UDMId:=","","MaterialValue:=",material,"SurfaceMaterialValue:=","\"\"","SolveInside:=",solveInside,"IsMaterialEditable:=",True,"UseMaterialAppearance:=",False,"IsLightweight:=",False])
        
        return x
    
    def createSub(self, length, width, height, dk):
        self.length=length        
        
        sub_name=self.AddMaterial(dk)
        name=self.createBox('sub',(0,-width/2,0),(length,width,-height), color="(143 175 143)", material='"{}"'.format(sub_name))
        self.objectName.append(name)
        
        name=self.createBox('gnd',(0,-width/2,-height),(length,width,-0.1), material='"copper"', solveInside=False)
        self.objectName.append(name)
        
        name=self.createBox('air',(0,-width/2,-height-0.1),(length,width,width/2), color="(128 128 255)")    
        self.objectName.append(name)         
        
    def createPair(self, width, gap, thickness):

        name=self.createBox('traceP',(0,-gap/2,0),(self.length,-width,thickness), material='"copper"', solveInside=False)
        self.objectName.append(name)
        name=self.createBox('traceN',(0,+gap/2,0),(self.length,+width,thickness), material='"copper"', solveInside=False)
        self.objectName.append(name)            

    def group(self):
        self.oEditor.CreateGroup(["NAME:GroupParameter","ParentGroupID:=","Model","Parts:=",','.join(self.objectName),"SubmodelInstances:=","","Groups:=",""])
        self.objectName=[]
        self.oEditor.FitAll()



class MyWindow(Window):
    def __init__(self, oDesktop):
        wpf.LoadComponent(self, 'CreateZdiff.xaml')
        self.calculate(self, None)
        self.x=createDiff(oDesktop)
        
    def textBox1_MouseEnter(self, sender, e):
        self.lb1.Content='Trace Width(mil)'
    
    def textBox_MouseEnter(self, sender, e):
        self.lb1.Content='Trace Separation(mil)'
    
    def tb_dk_MouseEnter(self, sender, e):
        self.lb1.Content='Relative Dielectric Constant'
    
    def tb_H_MouseEnter(self, sender, e):
        self.lb1.Content='Dielectric Thickness(mil)'
    
    def tb_T_MouseEnter(self, sender, e):
        self.lb1.Content='Trace Thickness(mil)'
    
    def calculate(self, sender, e):
        try:
            w=float(self.textBox1.Text)
            dk=float(self.tb_dk.Text)
            d=float(self.textBox.Text)
            h=float(self.tb_H.Text)
            t=float(self.tb_T.Text)
            zdiff=round((174/sqrt(dk+1.41))*log(5.98*h/(0.8*w+t))*(1-0.48*exp(-0.96*d/h)),3)
            self.lb2.Content='Zdiff: '+str(zdiff)+' (ohm)'
        except:

            self.lb2.Content='Calculation Failed!'  
    
    def Rectangle_MouseEnter(self, sender, e):
        self.lb1.Content=''
    
    def Button_Click(self, sender, e):
        l=float(self.tb_l.Text)
        w=float(self.tb_w.Text)
        h=float(self.tb_H.Text)
        dk=float(self.tb_dk.Text)
        wt=float(self.textBox1.Text)
        gt=float(self.textBox.Text)
        ht=float(self.tb_T.Text)
        self.x.createSub(l,w,h, dk)
        self.x.createPair(wt,gt,ht)
        self.x.group()
        self.run()
        self.close()
    
    def run(self):
        oProject = oDesktop.GetActiveProject()
        oDesign = oProject.GetActiveDesign()
        oDesign.SetSolutionType("DrivenTerminal", False)    
        oModule = oDesign.GetModule("BoundarySetup")
        oModule.AutoIdentifyPorts(["NAME:Faces",68],True,["NAME:ReferenceConductors","gnd"],"1",True)
        oModule.AutoIdentifyPorts(["NAME:Faces",66],True,["NAME:ReferenceConductors","gnd"],"2",True)
        oModule.AssignRadiation(["NAME:Rad1","Faces:=",[63,67,65],"IsFssReference:=",False,"IsForPML:=",False])
        oModule.EditDiffPairs(["NAME:EditDiffPairs",["NAME:Pair1","PosBoundary:=","traceN_T1","NegBoundary:=","traceP_T1","CommonName:=","Comm1","CommonRefZ:=","25ohm","DiffName:=","Diff1","DiffRefZ:=","100ohm","IsActive:=",True,"UseMatched:=",False]])
        oModule.EditDiffPairs(["NAME:EditDiffPairs",["NAME:Pair1","PosBoundary:=","traceN_T1","NegBoundary:=","traceP_T1","CommonName:=","Comm1","CommonRefZ:=","25ohm","DiffName:=","Diff1","DiffRefZ:=","100ohm","IsActive:=",True,"UseMatched:=",False],["NAME:Pair2","PosBoundary:=","traceN_T2","NegBoundary:=","traceP_T2","CommonName:=","Comm2","CommonRefZ:=","25ohm","DiffName:=","Diff2","DiffRefZ:=","100ohm","IsActive:=",True,"UseMatched:=",False]])
        oModule=oDesign.GetModule("AnalysisSetup")
        oModule.InsertSetup("HfssDriven",["NAME:Setup1","AdaptMultipleFreqs:=",False,"Frequency:=","10GHz","MaxDeltaS:=",0.02,"PortsOnly:=",False,"UseMatrixConv:=",False,"MaximumPasses:=",20,"MinimumPasses:=",1,"MinimumConvergedPasses:=",1,"PercentRefinement:=",30,"IsEnabled:=",True,"BasisOrder:=",1,"DoLambdaRefine:=",True,"DoMaterialLambda:=",True,"SetLambdaTarget:=",False,"Target:=",0.3333,"UseMaxTetIncrease:=",False,"PortAccuracy:=",2,"UseABCOnPort:=",False,"SetPortMinMaxTri:=",False,"UseDomains:=",False,"UseIterativeSolver:=",False,"SaveRadFieldsOnly:=",False,"SaveAnyFields:=",True,"IESolverType:=","Auto","LambdaTargetForIESolver:=",0.15,"UseDefaultLambdaTgtForIESolver:=",True])
        oModule.InsertFrequencySweep("Setup1",["NAME:Sweep","IsEnabled:=",True,"RangeType:=","LinearCount","RangeStart:=","0GHz","RangeEnd:=","20GHz","RangeCount:=",451,"Type:=","Interpolating","SaveFields:=",False,"SaveRadFields:=",False,"InterpTolerance:=",0.5,"InterpMaxSolns:=",250,"InterpMinSolns:=",0,"InterpMinSubranges:=",1,"ExtrapToDC:=",True,"MinSolvedFreq:=","0.01GHz","InterpUseS:=",True,"InterpUsePortImped:=",True,"InterpUsePropConst:=",True,"UseDerivativeConvergence:=",False,"InterpDerivTolerance:=",0.2,"UseFullBasis:=",True,"EnforcePassivity:=",True,"PassivityErrorTolerance:=",0.0001,"EnforceCausality:=",False])
        oProject.Save()
        oDesign.AnalyzeAll()
        oModule=oDesign.GetModule("ReportSetup")
        oModule.CreateReport("Terminal S Parameter Plot1","Terminal Solution Data","Rectangular Plot","Setup1:Sweep",["Domain:=","Sweep"],["Freq:=",["All"]],["X Component:=","Freq","Y Component:=",["dB(St(Diff1,Diff1))","dB(St(Diff2,Diff1))"]],[])
        oModule.ChangeProperty(["NAME:AllTabs",["NAME:Trace",["NAME:PropServers","Terminal S Parameter Plot1:dB(St(Diff2,Diff1))"],["NAME:ChangedProps",["NAME:Y Axis","Value:=","Y2"]]]])

if __name__ == '__main__':
    window = MyWindow(oDesktop)
    window.ShowDialog()
    