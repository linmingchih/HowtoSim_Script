config='''import os, sys, re, clr
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oEditor = oDesign.SetActiveEditor("3D Modeler")

class view3D():
    def __init__(self):
        oEditor.CreateRelativeCS(["NAME:RelativeCSParameters","Mode:=","Euler Angle ZYZ","OriginX:=","0mm","OriginY:=","0mm","OriginZ:=","0mm","Theta:=","0deg","Phi:=","0deg","Psi:=","0mm",],["NAME:Attributes","Name:=","ViewCS"])
        oEditor.FitAll()
        
    def spin(self, theta, phi, psi=0):
        oEditor.ChangeProperty(["NAME:AllTabs",["NAME:Geometry3DCSTab",["NAME:PropServers","ViewCS"],["NAME:ChangedProps",["NAME:Theta","Value:=",'{}deg'.format(theta)]]]])
        oEditor.ChangeProperty(["NAME:AllTabs",["NAME:Geometry3DCSTab",["NAME:PropServers","ViewCS"],["NAME:ChangedProps",["NAME:Phi","Value:=",'{}deg'.format(phi)]]]])
        oEditor.ChangeProperty(["NAME:AllTabs",["NAME:Geometry3DCSTab",["NAME:PropServers","ViewCS"],["NAME:ChangedProps",["NAME:Psi","Value:=",'{}deg'.format(psi)]]]])
        oEditor.SetTopDownViewDirectionForActiveView("ViewCS")
        
    def deleteCS(self):
        oEditor.Delete(["NAME:Selections","Selections:=","ViewCS"])
        
    def fitAll(self):
        oEditor.FitAll()
    

        #Code Start-----------------------------------
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'SpinView.xaml')
        
        try:
            self.v3D.deleteCS()
        except:
            pass
            
        self.v3D=view3D()
        self.view=[0,0,0]
        self._spin()
        
    def psi_Slider_ValueChanged(self, sender, e):
        self.view[2]=self.psi_Slider.Value
        self._spin()
    
    def phi_Slider_ValueChanged(self, sender, e):
        self.view[1]=self.phi_Slider.Value
        self._spin()
    
    def theta_Slider_ValueChanged(self, sender, e):
        self.view[0]=self.theta_Slider.Value
        self._spin()
        
    def fitall_BT_Click(self, sender, e):
        self.v3D.fitAll()
    
    def reset_BT_Click(self, sender, e):
        self.theta_Slider.Value=0
        self.phi_Slider.Value=0
        self.psi_Slider.Value=0
        self._spin()
    
    def Window_Closing(self, sender, e):
        try:
            self.v3D.deleteCS()
        except:
            pass
            
    def _spin(self):
        self.v3D.spin(*self.view)
        

#Code End-------------------------------------        
MyWindow().ShowDialog()

