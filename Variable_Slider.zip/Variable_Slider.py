config='''import os, sys, re, clr, collections
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Controls import ListBoxItem, Slider, Label
    from System.Windows.Controls.Primitives import AutoToolTipPlacement
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oEditor = oDesign.SetActiveEditor("3D Modeler")
unit=oEditor.GetModelUnits()
vars = collections.OrderedDict()

for i in oDesign.GetVariables():
    vars[i]= float(oDesign.GetVariableValue(i)[:-len(unit)])
    
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'Variable_Slider.xaml')
        for i in vars:
            s1=Slider()
            s1.Name=i
            s1.Height=30
            s1.AutoToolTipPrecision=3            
            s1.AutoToolTipPlacement=AutoToolTipPlacement.TopLeft
            s1.Value=vars[i]*1
            s1.Minimum=vars[i]*0.5
            s1.Maximum=vars[i]*2
            s1.ValueChanged += self.Slider_ValueChanged
            self.sp.Children.Add(s1)

            l1=Label()
            l1.Height=30
            l1.Content=i
            self.spn.Children.Add(l1)
        
    def Slider_ValueChanged(self, sender, e):
        oDesign.ChangeProperty(
            [
                "NAME:AllTabs",
                [
                    "NAME:LocalVariableTab",
                    [
                        "NAME:PropServers", 
                        "LocalVariables"
                    ],
                    [
                        "NAME:ChangedProps",
                        [
                            "NAME:{}".format(sender.Name),
                            "Value:="		, "{}{}".format(sender.Value,unit)
                        ]
                    ]
                ]
            ])
            
MyWindow().ShowDialog()

