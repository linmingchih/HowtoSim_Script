import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
name=oProject.GetName()
prj_dir=oProject.GetPath()
try:
    oDesign.ExportNetworkData("", ["HFSS Setup 1:Sweep1"], 3, "{}/{}.snp".format(prj_dir,name), ["All"], True, 50, "S", -1, 0, 15, True, True, False)
    oDesign.ExportProfile("HFSS Setup 1", "", "{}/{}.prof".format(prj_dir,name))
except:
    oDesign.ExportNetworkData("", ["SIwave Setup 1:Sweep1"], 3, "{}/{}.snp".format(prj_dir,name), ["All"], True, 50, "S", -1, 0, 15, True, True, False)    
    oDesign.ExportProfile("SIwave Setup 1", "", "{}/{}.prof".format(prj_dir,name))