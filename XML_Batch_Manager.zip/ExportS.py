import ScriptEnv, os
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
name=oProject.GetName()
prj_dir=oProject.GetPath()
data_dir=prj_dir+'/'+'data'
if not os.path.exists(data_dir):
    os.makedirs(data_dir)

try:
    oDesign.ExportNetworkData("", ["HFSS Setup 1:Sweep1"], 3, "{}/{}.snp".format(data_dir,name), ["All"], True, 50, "S", -1, 0, 15, True, True, False)
    oDesign.ExportProfile("HFSS Setup 1", "", "{}/{}.prof".format(data_dir,name))
except:
    oDesign.ExportNetworkData("", ["SIwave Setup 1:Sweep1"], 3, "{}/{}.snp".format(data_dir,name), ["All"], True, 50, "S", -1, 0, 15, True, True, False)    
    oDesign.ExportProfile("SIwave Setup 1", "", "{}/{}.prof".format(data_dir,name))