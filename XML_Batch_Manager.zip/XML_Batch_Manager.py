import wpf
import clr, time
import re, sys, os, subprocess
clr.AddReference("System.Windows.Forms")
from System.Windows import Application, Window
from System.Windows.Forms import FolderBrowserDialog, OpenFileDialog, DialogResult
from shutil import copyfile

os.environ["PATH"] += r";C:\Program Files\AnsysEM\AnsysEM19.4\Win64"
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'XML_Batch_Manager.xaml')
        self.wkdir=self.wk_tb.Text
        self.refresh_listbox()

    def wk_tb_MouseDoubleClick(self, sender, e):
        dialog = FolderBrowserDialog()
        if (dialog.ShowDialog() == DialogResult.OK):
            self.wk_tb.Text = dialog.SelectedPath
            self.wkdir=self.wk_tb.Text
            self.refresh_listbox()

    def add_bt_Click(self, sender, e):
        if not os.path.isdir(self.wkdir):
            self.wk_tb.Text='Please Select Working Directory'
            return None

        dialog = OpenFileDialog()
        dialog.Multiselect=True
        dialog.Filter = "XML files (*.xml)|*.xml"
        if dialog.ShowDialog() == DialogResult.OK:
            for i in dialog.FileNames:
                copyfile(i, self.wkdir+'/'+os.path.basename(i))
        self.refresh_listbox()     
        
    def get_xmls_in_wd(self):
        xmls=[]
        for file in os.listdir(self.wkdir):
            if file.endswith(".xml"):
                xmls.append(os.path.basename(file))
        return xmls

    def refresh_listbox(self):
        self.case_lb.Items.Clear()
        for i in self.get_xmls_in_wd():
            
            self.case_lb.Items.Add(i)

    
    def wk_tb_TextChanged(self, sender, e):
        pass
    
    def delete_bt_Click(self, sender, e):
        for i in self.case_lb.SelectedItems:
            os.remove(self.wkdir+'/'+i)
        self.refresh_listbox()  
        

    def pin2pin_bt_Click(self, sender, e):
        subprocess.call(['PinToPinSetup.exe'])

    
    def source_bt_Click(self, sender, e):
        dialog = FolderBrowserDialog()
        if (dialog.ShowDialog() == DialogResult.OK):
            source = dialog.SelectedPath

            for xml in self.case_lb.Items:
                path=self.wkdir+'/'+xml
                with open(path) as f:
                    text=f.read()          
                    text=re.sub('SourceDataFileName=".*?"','SourceDataFileName="{}"'.format(source),text)
                with open(path, 'w') as f:
                    f.write(text)

    def case_lb_MouseDoubleClick(self, sender, e):
        xml_path=self.wkdir+'/'+self.case_lb.SelectedItem
        with open(xml_path) as f:
            self.data_tb.Text=f.read()
            self.xml_lb.Content=self.case_lb.SelectedItem
            if 'SIwaveSetup' in self.data_tb.Text:
                self.xml_lb.Content+=' (SIwave)'
            else:
                self.xml_lb.Content+=' (HFSS)'

    
    def run_bt_Click(self, sender, e):
        cores=self.core_tb.Text
        summary=''
        for i in self.case_lb.Items:
            summary+=i+': '
            Tstart=time.time()
            self.xml_lb.Content=i
            xml_path='{}/{}'.format(self.wkdir, i)
            aedb_path='{}/{}'.format(self.wkdir, i[:-4]+'.aedb')
            aedt_path='{}/{}'.format(self.wkdir, i[:-4]+'.aedt')

            subprocess.call(['PinToPinSetup.exe', self.wkdir, xml_path, aedb_path])
            subprocess.call(['ansysedt.exe', '-ng', '-monitor', '-batchsolve', '-machinelist', 'num={}'.format(cores), aedb_path])
            subprocess.call(['ansysedt.exe', '-ng','-batchextract', 'ExportS.py', aedt_path])
            summary+='{}(sec)\n'.format(time.time()-Tstart)

        self.xml_lb.Content='Simulation Summary:'
        self.data_tb.Text=summary

if __name__ == '__main__':
    Application().Run(MyWindow())
