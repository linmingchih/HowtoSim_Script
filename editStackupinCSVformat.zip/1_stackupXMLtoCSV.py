# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 08:46:44 2019

@author: mlin
"""

import re
import os
oDesktop.ClearMessages('','',2)
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oEditor = oDesign.SetActiveEditor("Layout")

prj_path=oProject.GetPath()
xml_path=prj_path+"stackup.xml"
csv_path=xml_path[:-3]+'csv'
oEditor.ExportStackupXML(xml_path)

def stackupXMLtoCSV():
    with open(xml_path) as f:
        text=''.join([i.strip() for i in f.readlines()])
    
    layers=re.findall('<Layer.*?\sMaterial="(.*?)".*?Name="(.*?)".*?Thickness="(.*?)".*?Type="(.*?)"', text)
    materials=re.findall('Name="(\S*?)"><Permittivity><Double>(.*?)</Double>.*?<DielectricLossTangent><Double>(.*?)</Double>', text)
    
    material_dic={i[0]:(i[1], i[2]) for i in materials}
    data='type, name, thickness, dk, df\n'
    for material, name, thickness, _type in layers:
        try:
            data+='{},{},{},{},{}\n'.format(_type, name, thickness, *material_dic[material])
        except:
            data+='{},{},{}\n'.format(_type, name, thickness)

    with open(csv_path, 'w') as f:
        f.write(data)

stackupXMLtoCSV()

AddWarningMessage('{} is saved!'.format(csv_path))   
os.system('start excel.exe {}'.format(csv_path))