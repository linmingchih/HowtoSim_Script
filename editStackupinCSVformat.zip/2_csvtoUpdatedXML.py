# -*- coding: utf-8 -*-
"""
Created on Sat Dec 28 11:10:22 2019

@author: mlin
"""
import clr
import re
import os
oDesktop.ClearMessages('','',2)
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
oEditor = oDesign.SetActiveEditor("Layout")
prj_path=oProject.GetPath()
xml_path=prj_path+"stackup.xml"
csv_path=xml_path[:-3]+'csv'
updated_xml_path=csv_path[:-4]+'_updated.xml'

def csvtoUpdatedXML():
    xml_path=csv_path[:-3]+'xml'

    
    with open(csv_path) as f:
        layers=[i.strip().split(',') for i in f.readlines()[1:]]
    
    
    material_string='''      <Material Name="FR{0}_{1}">
            <Permittivity>
              <Double>{0}</Double>
            </Permittivity>
            <DielectricLossTangent>
              <Double>{1}</Double>
            </DielectricLossTangent>
          </Material>\n'''
          
    dielectrics=set()
    for i in layers:
        if len(i)==5:
            dielectrics.add(material_string.format(i[3],i[4]))
            
    with open(xml_path) as f:
        text=f.readlines()
    
    result=[]
    
    metal_pattern='(<Layer.*?FillMaterial=)(".*?")(.*?Name=)(".*?")(.*?Thickness=)(".*?")(.*conductor.*)'
    dielectric_pattern='(<Layer.*?Material=)(".*?")(.*?Name=)(".*?")(.*?Thickness=)(".*?")(.*dielectric.*)'
    
    n=0
    material=''
    for i in text:
        if '<Materials>' in i:
            result+=[i]
            result+=dielectrics
            continue
        m=re.search(metal_pattern, i)
        if m:
            _, name, thickness=layers[n][0:3]
            n+=1
            i=re.sub('(<Layer.*?FillMaterial=)(".*?")(.*?Name=)(".*?")(.*?Thickness=)(".*?")(.*conductor.*)', 
                     r'\1"{}"\3"{}"\5"{}"\7'.format(material, name, thickness), i)    
        
        m=re.search(dielectric_pattern, i)
        if m:
            _, name, thickness, dk, df=layers[n]
            n+=1
            material='FR{}_{}'.format(dk, df)
            i=re.sub('(<Layer.*?Material=)(".*?")(.*?Name=)(".*?")(.*?Thickness=)(".*?")(.*dielectric.*)', 
                     r'\1"{}"\3"{}"\5"{}"\7'.format(material, name, thickness), i)
    
        result+=[i]
    with open(updated_xml_path, 'w') as f:
        f.write(''.join(result))
        return updated_xml_path

csvtoUpdatedXML()
oEditor.ImportStackupXML(updated_xml_path)
AddWarningMessage('{} is imprted!'.format(csv_path))   
