config='''import os, sys, re, clr, math
try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.3/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  
    
    import wpf
    from System.Windows import Window
    from System.Windows.Forms import DialogResult, SaveFileDialog
    os.chdir(os.path.dirname(__file__))
'''
exec(config)

class vec():
    def __init__(self, v):
        self.v=v
        self.len=math.sqrt(sum([i*i for i in self.v]))
    
    def __add__(self, other):
        return vec([i+j for i,j in zip(self.v, other.v)])
    
    def __sub__(self, other):
        return vec([i-j for i,j in zip(self.v, other.v)])
    
    def __mul__(self, k):
        return vec([i*k for i in self.v])
    
    def unit(self):
        return vec([i/self.len for i in self.v])
    
    def location(self):
        return ' '.join([str(i) for i in self.v])
        
def exportPTS(x, ds, ptsfile):
    m=re.findall('(\[.*\])(\w+)',x)
    p=[vec(j) for j in [eval(i[0]) for i in m]]
    model_unit=m[0][1]
    
    Vx, Vy=p[1]-p[0], p[2]-p[0]
    pts=[]
    usize, vsize=int(Vx.len/ds)+1, int(Vy.len/ds)+1
    for u in range(usize):
        for v in range(vsize):
            x=p[0]+Vx.unit()*(ds*u)+Vy.unit()*(ds*v)
            pts.append(x.location())
    
    with open(ptsfile, 'w') as f:
        f.writelines('Unit={}\n'.format(model_unit))
        f.writelines('\n'.join(pts))
    
    return (usize, vsize)
    
#Code Start-----------------------------------
class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'exportPTS.xaml')
        
    def bt_Click(self, sender, e):        
        dialog = SaveFileDialog()
        dialog.Title = 'Save .pts file'
        dialog.Filter = 'PTS file|*.pts'

        if dialog.ShowDialog() == DialogResult.OK:
            try:
                usize,vsize=exportPTS(self.tb1.Text, float(self.tb2.Text), dialog.FileName)
                self.tb1.Text='Export {} successfully! size:{},{}'.format(dialog.FileName, usize, vsize)
            except:
                self.tb1.Text='Failed to export! Please examine your input.'
        

#Code End-------------------------------------        
MyWindow().ShowDialog()

