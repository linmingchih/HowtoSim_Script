
import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()

oProject = oDesktop.GetActiveProject()

def createtrl(name, trl, sub):
    oProject = oDesktop.NewProject()
    oProject.InsertDesign("HFSS", name, "DrivenModal", "")
    oDesign = oProject.SetActiveDesign(name)
    oEditor = oDesign.SetActiveEditor("3D Modeler")
    
    oDefinitionManager = oProject.GetDefinitionManager()    
    oDefinitionManager.AddMaterial(
        [
            "NAME:sub",
            "CoordinateSystemType:=", "Cartesian",
            "BulkOrSurfaceType:="	, 1,
            [
                "NAME:PhysicsTypes",
                "set:="			, ["Electromagnetic"]
            ],
            "permittivity:="	, sub['Er'],
            "dielectric_loss_tangent:=", sub['TanD']
        ])  
    oEditor.CreateBox(
        [
            "NAME:substrate",
            "XPosition:="		, "0mm",
            "YPosition:="		, "-10*{}".format(float(trl['W'])/2),
            "ZPosition:="		, "0mm",
            "XSize:="		, trl['P'],
            "YSize:="		, "20*{}".format(float(trl['W'])/2),
            "ZSize:="		, '-{}'.format(sub['H'])
        ], 
        [
            "NAME:Attributes",
            "Name:="		, "Box1",
            "Flags:="		, "",
            "Color:="		, "(157 249 158)",
            "Transparency:="	, 0,
            "PartCoordinateSystem:=", "Global",
            "UDMId:="		, "",
            "MaterialValue:="	, "\"sub\"",
            "SurfaceMaterialValue:=", "\"\"",
            "SolveInside:="		, True,
            "IsMaterialEditable:="	, True,
            "UseMaterialAppearance:=", False,
            "IsLightweight:="	, False
        ])


    oDefinitionManager.AddMaterial(
        [
            "NAME:metal",
            "CoordinateSystemType:=", "Cartesian",
            "BulkOrSurfaceType:="	, 1,
            [
                "NAME:PhysicsTypes",
                "set:="			, ["Electromagnetic"]
            ],
            "conductivity:="	, "50000000"
        ])
    oEditor.CreateBox(
        [
            "NAME:BoxParameters",
            "XPosition:="		, "0",
            "YPosition:="		, "-{}".format(float(trl['W'])/2),
            "ZPosition:="		, "0",
            "XSize:="		, trl['P'],
            "YSize:="		, "{}".format(float(trl['W'])),
            "ZSize:="		, sub['T1']
        ], 
        [
            "NAME:Attributes",
            "Name:="		, "line",
            "Flags:="		, "",
            "Color:="		, "(255 0 128)",
            "Transparency:="	, 0,
            "PartCoordinateSystem:=", "Global",
            "UDMId:="		, "",
            "MaterialValue:="	, "\"metal\"",
            "SurfaceMaterialValue:=", "\"\"",
            "SolveInside:="		, True,
            "IsMaterialEditable:="	, True,
            "UseMaterialAppearance:=", False,
            "IsLightweight:="	, False
        ])
    oEditor.CreateRectangle(
        [
            "NAME:RectangleParameters",
            "IsCovered:="		, True,
            "XStart:="		, "0mm",
            "YStart:="		, "-10*{}".format(float(trl['W'])/2),
            "ZStart:="		, "-{}".format(sub['H']),
            "Width:="		, trl['P'],
            "Height:="		, "20*{}".format(float(trl['W'])/2),
            "WhichAxis:="		, "Z"
        ], 
        [
            "NAME:Attributes",
            "Name:="		, "gnd",
            "Flags:="		, "",
            "Color:="		, "(255 0 128)",
            "Transparency:="	, 0,
            "PartCoordinateSystem:=", "Global",
            "UDMId:="		, "",
            "MaterialValue:="	, "\"vacuum\"",
            "SurfaceMaterialValue:=", "\"\"",
            "SolveInside:="		, True,
            "IsMaterialEditable:="	, True,
            "UseMaterialAppearance:=", False,
            "IsLightweight:="	, False
        ])
    oModule = oDesign.GetModule("BoundarySetup")
    oModule.AssignPerfectE(
        [
            "NAME:PerfE",
            "Objects:="		, ["gnd"],
            "InfGroundPlane:="	, False
        ])
        
    oEditor.FitAll()
        
        
x={'sub': {'Substrate': {'H': '0.001', 'Er': '2.2', 'TanD': '0', 'TANM': '0', 'MSat': '0', 'MRem': '0', 'HU': '0.025', 'MET1': '1.724138', 'T1': '1.778e-05'}, 'Substrate1': {'H': '0.001', 'Er': '4', 'TanD': '0', 'TANM': '0', 'MSat': '0', 'MRem': '0', 'HU': '0.025', 'MET1': '1.724138', 'T1': '1.778e-05'}}, 'trl': {'A4': {'W': '0.00305117', 'P': '0.05', 'SUBSTRATE': 'Substrate1'}}, 'mcpl': {'A5': {'W': '0.001', 'SP': '0.001', 'P': '0.01', 'SUBSTRATE': 'Substrate1'}}}
        
for i in x['trl']:
    subname=x['trl'][i]['SUBSTRATE']
    createtrl(i, x['trl'][i], x['sub'][subname])

