# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 08:02:01 2019

@author: mlin
"""

import re

def getMicroStripInfo(netlist):
    
    with open(netlist) as f:
        text=f.read().replace('\n+',' ').splitlines()
    
    sub={}
    for i in text:
        m=re.search('.SUB\s(.*?)\s.*H=(.*) Er=(.*) TAND=(.*) TANM=(.*) MSat=(.*) MRem=(.*) HU=(.*) MET1=(.*) T1=(.*)\)',i)
        if m:
            sub[m.group(1)]={'H':m.group(2), 'Er':m.group(3), 'TanD':m.group(4), 
                'TANM':m.group(5),'MSat':m.group(6),'MRem':m.group(7),'HU':m.group(8),
                'MET1':m.group(9),'T1':m.group(10)}
    trl={}
    for i in text:
        m=re.search('(.*?)\s.*W=(.*) P=(.*) COMPONENT=TRL SUBSTRATE=(.*)',i)
        if m:
            trl[m.group(1)]={'W':m.group(2), 'P':m.group(3),'SUBSTRATE':m.group(4)}
            
    mcpl={}
    for i in text:
        m=re.search('(.*?)\s.*W=(.*) SP=(.*) P=(.*) SUBSTRATE=(.*) NL=2 COMPONENT=mcpl',i)
        if m:
            mcpl[m.group(1)]={'W':m.group(2), 'SP':m.group(3),'P':m.group(4),'SUBSTRATE':m.group(5)}
    
    return {'sub':sub, 'trl':trl, 'mcpl':mcpl}

#oDesign.ExportNetlist('','d:/demo/test.net')
info=getMicroStripInfo('d:/demo/test.net')
print(info)