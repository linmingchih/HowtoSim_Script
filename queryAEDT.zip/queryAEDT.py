config='''import os, sys, re, clr, json,webbrowser, importlib

try:
    dll_dir='C:/Program Files/AnsysEM/AnsysEM19.4/Win64/common/IronPython/DLLs'
    if not os.path.isdir(dll_dir):
        raise Exception 
except:
    m=re.search('(.*Win64)', __file__)
    dll_dir=m.group(1)+'/common/IronPython/DLLs'
finally:
    sys.path.append(dll_dir)
    clr.AddReference('IronPython.Wpf')  

    clr.AddReference('System.Drawing')
    clr.AddReference('System.Windows.Forms')
    import wpf
    from System.Windows import Window
    from System.Windows.Forms import  SaveFileDialog, DialogResult
'''
exec(config)
html='''<!DOCTYPE html>
<html>
<head>
    <style>
    table.fixed {{
        table-layout:fixed; 
        }}
    table.fixed td {{
        overflow: hidden; 
        }}
    </style>
</head>
<body>{}</body>
'''

sys.path.append('C:/Program Files/AnsysEM/AnsysEM19.4/Win64/')
sys.path.append('C:/Program Files/AnsysEM/AnsysEM19.4/Win64/PythonFiles/DesktopPlugin/')


def returnTable(li,N):
    x=''
    n=0
    for i in li:
        if n==0:
            x+='<tr>'
        x+='<td>{}</td>'.format(i)
        n+=1
        if n==N:
            x+='</tr>\n'
            n=0
    return '<table class="fixed">\n<col width="360px"/>\n<col width="360px"/>\n<col width="360px"/>{}</table>'.format(x)

def generateHtml(funcs, html_name):
    html_path=html_name

    x=''
    for i in funcs:
        x+='<h2 style="color:red";>{}</h2>'.format(i)
        x+=returnTable(funcs[i],3)

       
    with open(html_path,'w') as sf:
        sf.writelines(html.format(x))        

    webbrowser.open('file://' + os.path.realpath(html_path))
    
#--------------------------------------------------------------------     
   
import ScriptEnv
from collections import OrderedDict

ScriptEnv.Initialize("AnsoftHfss.HfssScriptInterface")
oProject = oDesktop.NewProject()
oDefinitionManager = oProject.GetDefinitionManager()

def exportFunctions(oDesign, oEditor):
    data=OrderedDict()
    data['oDesktop']=dir(oDesktop)
    data['oProject']=dir(oProject)
    data['oDefinitionManager']=dir(oDefinitionManager)
    data['oDesign']=dir(oDesign)
    data['Editor']=dir(oEditor)
    
    for m in ["BoundarySetup","MeshSetup","AnalysisSetup","SimSetup","Optimetrics","Solutions","SolveSetups","ModelSetup","FieldsReporter","RadField","ReduceMatrix","ReportSetup","OutputVariable","UserDefinedSolutionModule","DV","Excitations"]:
        try:
            data['module-'+m]= dir(oDesign.GetModule(m))
        except:
            pass
    
    return data

#HFSS
oDesign = oProject.InsertDesign("HFSS", "HFSSDesign1", "DrivenModal", "")
oEditor = oDesign.SetActiveEditor("3D Modeler")
data=exportFunctions(oDesign, oEditor)
generateHtml(data, '19R2_HFSS.html')

#3D Layout
oDesign = oProject.InsertDesign("HFSS 3D Layout Design", "EMDesign1", "", "")
oEditor = oDesign.SetActiveEditor("Layout")
data=exportFunctions(oDesign, oEditor)
generateHtml(data, '19R2_3D Layout.html')

#Circuit
oDesign = oProject.InsertDesign("Circuit Design", "Circuit1", "", "")
oEditor = oDesign.SetActiveEditor("SchematicEditor")
data=exportFunctions(oDesign, oEditor)
generateHtml(data, '19R2_Circuit.html')

#Q3D
oDesign=oProject.InsertDesign("Q3D Extractor", "Q3DDesign1", "", "")
oEditor = oDesign.SetActiveEditor("3D Modeler")
data=exportFunctions(oDesign, oEditor)
generateHtml(data, '19R2_Q3D.html')

